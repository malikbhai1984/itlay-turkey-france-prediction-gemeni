## 16. Daily match log & lessons (2026-27)

**Note:** naye finished matches ka record. Saare section numbers (1-14) har update par poore data se dobara bante hain.

| Date | Match | HT | Goals | 81+ goals | Comeback (team, result, deficit, minute) | Red card |
|---|---|---|---|---|---|---|
| 10-09 | Lens 2-1 Lyon | 1-0 | Lens 36', Lens 76', Lyon 85' | Lyon 85' | - | Lens |
| 10-10 | Lille 1-0 Le Havre | 1-0 | Lille 5' | - | - | Le Havre |
| 10-10 | Brest 5-1 Angers | 4-0 | Brest 9', Brest 17', Brest 30', Brest 45', Angers 47', Brest 54' | - | - | Angers |
| 10-10 | Lorient 1-0 Paris FC | 0-0 | Lorient 68' | - | - | - |
| 10-10 | Monaco 2-2 Toulouse | 2-0 | Monaco 29', Monaco 38', Toulouse 48', Toulouse 59' | - | Toulouse (Draw, -2, 59') | - |
| 10-10 | Paris SG 3-1 Le Mans | 1-0 | Paris SG 19' (pen), Le Mans 54', Paris SG 61', Paris SG 68' | - | - | - |
| 10-11 | Nice 2-1 Strasbourg | 1-1 | Strasbourg 41', Nice 45', Nice 81' | Nice 81' | Nice (Win, -1, 45') | - |
| 10-11 | Rennes 4-1 Auxerre | 1-1 | Rennes 15', Auxerre 25', Rennes 53', Rennes 90', Rennes 90' | Rennes 90', Rennes 90' | - | - |
| 10-11 | Troyes 0-2 Marseille | 0-0 | Marseille 50', Marseille 90' | Marseille 90' | - | - |

**Lessons (09-11 Oct, 9 matches):**
1. **Late goals:** 4/9 matches me 81'+ goal aaya (44%; league base 41.7%): Lens-Lyon 85', Nice 81', Rennes 90'+90', Marseille 90'. 3 late goals aage wali team ne kiye (Rennes x2, Marseille) — databook ke Late_Goals register ka pattern 'late goal aksar lead barhata hai' confirm. Nice ka 81' goal barabar match ka winner bana; Lyon ka 85' sirf consolation tha.
2. **Comebacks (2):** Toulouse 0-2 se 2-2 (goals 48' aur 59', dono HT ke baad 14 min ke andar); Nice 0-1 (41') se 1-1 (45', conceding ke 4 min baad) aur phir 81' winner. Common: dono comeback goals HT ke qareeb ya 2nd-half ke shuru me aaye, aur dono kisi ek goal se peeche nahi rahe — jald jawab Section 8 ke 'quick response' signal se match karta hai.
3. **HT lead:** 5 me se 4 HT leads hold hui (Lens, Lille, Brest 4-0, PSG). Monaco ki 2-0 HT lead 2-2 me badli — yeh wahi ~10% case hai jo Section 7 me aata hai. Kabhi 100% mat maanen.
4. **Red cards (3):** Lens 84' (phir bhi jeeta), Le Havre 61' (0-1 haara), Angers 59' (1-5 haara, pehle hi 0-4 peeche). Red wali team 3 me se 2 haari/peeche rahi; Lens ka case sirf isliye bacha ke red 84' me tha.
5. **1-0 jeeten:** Lille (5 shots vs 17) aur Lorient (7 vs 10) kam shots ke bawajood jeete — shot-dominance win ~50% hi hai (Section 14.4).
6. **PSG 3-1:** 21 shots, 73% possession, phir bhi Le Mans ne 54' me barabar kiya; PSG ne 7 aur 14 min baad jawab diya.

### 16 Oct 2026 — user ke sawal: "yeh aisa kyun hua?" (10-11 Oct, Flashscore stats ke saath)
Numbers Section 21 se hain (16 Oct ke data par). **Aam** = purane matches me aksar; **surprise** = kam.

| Match | Sawal | Purane matches (Ligue 1 / teeno) | Match stats (xG, SOT) | Faisla |
|---|---|---|---|---|
| Lille 1-0 Le Havre | Sirf 1 goal, 2nd half me kyun nahi? | Home 1-0 HT → 2nd half 0 goal: 20% / 21% (away red ke saath 29%) | xG 1.26-1.28 (barabar), Lille ke 5 shots / 1 SOT, Le Havre ke 17 shots / 2 SOT (xGOT 0.05) | Thora surprise. Lille ne 5' ke goal ke baad defend kiya; Le Havre ke shots door se aur kamzor the, phir red card |
| Brest 5-1 Angers | 6 goal kyun, 54' ke baad kyun nahi? | 55' par 4+ farq → 75' ke baad goal nahi: 67% / 59% | xG 3.82-1.39 (total 5.2 → Over 2.5 band 85%), SOT 9-3 | Aam. 6 goal xG ke mutabiq the; 5-1 ke baad match khatam, Brest ne scorers nikaale, Angers 59' se 10 aadmi |
| Lorient 1-0 Paris FC | 1 goal, BTTS kyun nahi? | 0-0 HT → sirf 1 goal: 31%, BTTS No: 74% | (stats nahi) — report: Paris FC ne mauqe zaya kiye | Aam. HT 0-0 wala match zyada tar 0-1 goal aur BTTS No par jata hai |
| Monaco 2-2 Toulouse | 60' ke baad goal kyun nahi? | Home 2-0 HT → draw: 8% (surprise); 2-2 at 60' → aur goal nahi: 39% | Toulouse ke dono goal 48' (pen) aur 59' | Draw surprise tha; uske baad 2-2 ruk jana aam hai. Comeback ke baad dono teams "point bachao" mode me |
| Paris SG 3-1 Le Mans | 68' ke baad goal kyun nahi, BTTS kyun? | Home 1-0 HT → BTTS: 47%; 2 goal lead at 70' → aur goal nahi: 42% | xG 4.25-1.43, Le Mans ke 4 big chances | BTTS aam hai jab dog chances banaye (1.43 xG). 3-1 ke baad PSG ne Doue/Hakimi nikaale aur 73% ball se waqt guzara |
| Nice 2-1 Strasbourg | 1-1 ke baad 81' goal kyun? | 1-1 at 80' → aur goal: 50% (Ligue 1 me Serie A se zyada) | xG 1.25-0.63, SOT 6-3, big chances 4-0 | Aam / coin-flip. Behtar team (Nice) ne aakhir me goal kiya; sub Diop ne assist di |
| Rennes 4-1 Auxerre | Aakhri 5 min me 2 goal kyun? | 1 goal lead at 85' → 85' ke baad 2+ goal: 5% (nadir) | Sub Dia (77') ne dono goal kiye | Surprise. Auxerre barabari ke liye aage gaya, Rennes ne counter par 2 goal kiye. Rule mat banao |
| Troyes 0-2 Marseille | BTTS kyun nahi, 90+8' goal kyun? | HT 0-0 phir away 0-1 → BTTS: 50% (coin-flip); 90'+ goal: 22% | Troyes ke 15 shots me 3 on target (xGOT 0.16), 2 baar post | Coin-flip. Troyes ne shots kiye lekin kamzor; aakhir me Troyes aage aaya to penalty mili |

**Sabaq (agle matches ke liye):**
1. **Ligue 1 me 1-1 at 80' = 50/50.** Serie A (36%) se zyada late goal. Ligue 1 me "80' ke baad goal" ko Serie A se zyada weight do, lekin fair odds ~2.00 hai — 2.10+ par hi value.
2. **Shots ka count dhoka hai, SOT/xGOT dekho.** Le Havre (17 shots, xGOT 0.05) aur Troyes (15 shots, xGOT 0.16) ne goal nahi kiya. Total SOT 0-4 → Over 2.5 sirf ~8% (Section 21.3).
3. **2-0 HT lead bhi 'pakki' nahi:** ~8-10% draw (Monaco). Home 2-0 HT par "home win" ka fair odds ~1.12 hai; 1.80+ ki value nahi.
4. **Big xG gap = goals:** Brest (3.82) aur PSG (4.25) — total xG 3.5+ wale matches me Over 2.5 ~85%. Live xG aisa ho to Over (current + 1.5) socho.
5. **Bari lead ke baad scorers ka sub-off** (Brest, PSG, Inter) = aakhri 20 min me goal ka chance kam. Live me line-up changes dekho.

### 16 Oct 2026 — Le Mans 0-3 Toulouse
| Date | Match | HT | Goals | 81+ goals | Comeback | Red card |
|---|---|---|---|---|---|---|
| 10-16 | Le Mans 0-3 Toulouse | 0-0 | Toulouse 46' (Russell-Rowe), 59' (Donnum), 87' (Tengstedt) | Toulouse 87' | - | - |

Stats: xG 0.95-1.81, SOT 1-5, xGOT 0.16-3.19, big chances 2-2 (Le Mans 0 scored), crosses 35-4, possession 53-47. Le Mans 61' par 3 subs; Toulouse 75' goal offside. Cards: Russell-Rowe 49' (unsportsmanlike), Yohou 90' (tripping).

| Sawal | Purane matches | Stats | Faisla |
|---|---|---|---|
| BTTS kyun nahi? | HT 0-0 → BTTS No 74% (Ligue 1 n=272); home SOT ≤1 → home 0 goal 75% (n=55); away 0-2 at 60' → home goal sirf 43% | Le Mans 1 SOT, xGOT 0.16, 2 big chances miss | **Aam natija** |
| 87' goal kyun? | 2 goal lead at 80' → 81'+ goal 39% (n=191); un me 50% aage wali team ka | Le Mans 3 subs 61', 35 crosses; Toulouse counter | Coin-flip, surprise nahi |

**Sabaq:** (1) Live HT 0-0 par BTTS No zaroor check karo (~74%). (2) SOT ≤1 wali team ka goal na karna ~75%. (3) 2 goal lead ke baad bhi late goal ~40% — Under (current+0.5) late me risky.

### 17-18 Oct 2026 (Ligue 1, Round 7) — 7 matches
(Dates: PSG match 17 Oct 20:15 confirmed; baaki 6 matches ki tareekh 18 Oct andaaza hai, Flashscore dump me nahi thi. Odds sirf jahan dump me thi.)
| Match | FT (HT) | Goals | xG | SOT | Odds 1X2 |
|---|---|---|---|---|---|
| Strasbourg 1-3 PSG | 1-3 (1-0) | Str 17'; PSG 77', 85', 90+3' | 1.47-2.69 | 8-7 | 5.90/5.35/1.46 |
| Lille 1-1 Brest | 1-1 (0-1) | Brest 6'; Lille 64' (pen) | 2.17-0.78 | 5-2 | 2.12/3.48/3.54 |
| Troyes 1-3 Lens | 1-3 (1-2) | Lens 13' (og), Troyes 26', Lens 45+2', 55' | 1.24-1.43 | 5-3 | - |
| Angers 2-5 Marseille | 2-5 (1-2) | Ang 14', 75'(pen); OM 37', 43', 60', 83', 85' | 2.21-2.71 | 3-8 | - |
| Le Havre 1-3 Auxerre | 1-3 (0-1) | Aux 40', 61'; LH 66'; Aux 80' | 1.40-2.70 | 6-6 | 2.31/3.61/3.01 |
| Paris FC 4-3 Rennes | 4-3 (2-1) | PFC 14', 45+4'; Rennes 29'(pen); Rennes 74'(pen); PFC 76'; Rennes 88'(pen); PFC 90+7'(pen) | 3.62-3.35 | 9-7 | 2.04/3.82/3.46 |
| Lyon 2-1 Nice | 2-1 (2-1) | Nice 18'; Lyon 32', 36' | 1.51-1.55 | 4-5 | - |

**1. Strasbourg-PSG: aakhri 10 min me 2 goal kyun?** PSG ka odds 1.46 tha. Data: strong fav (<1.60) HT par peeche ho to jeet sirf 32%, draw 31%, haar 37% (n=108) — yaani 1.46 ka fav HT par peeche ho to "pakka" nahi rehta. PSG ne 72' par penalty miss ki, 77' barabari, 85' aur 90+3' goal. Pura match xG 2.69-1.47 PSG ke haq me, SOT 7-8 lekin PSG ke 5 big chance miss. Aakhri 10 min me 2+ goal sirf 8% matches me aate hain (n=3115) — yeh **rare** hai, rule nahi. Seekh: strong fav peeche ho to "late comeback" live bet tabhi jab xG usi ke haq me ho (yahan tha), lekin odds 1.46 -> peeche hone par live odds ~2.5-3.0 mil jate hain.
**2. Lille-Brest 1-1, comeback kyun, Under 2.5?** Lille xG 2.17 vs 0.78, 17 shots vs 8 par Brest ke GK/defence ne 39 clearances kiye (Lille 44 touches box). Brest 6' par pehla shot goal. HT 0-1 par home fav (1.9-2.3) ka FT: jeet 21%, draw 33%, haar 46% (n=95), Under 2.5 47%. Giroud penalty ke baad draw. Barabar-sa score ka wajah: Lille ka finishing (5 SOT, 3 big chance, sirf 1 goal+penalty). Under 2.5 kyun: sirf 2 goal — Brest 39 clearances ke saath gehra defend karta raha (sirf 8 shots, 2 SOT) aur Lille ka xG 2.17 me se 1 open-play goal hi bana (xG se kam finishing).
**3. Troyes-Lens: 60' ke baad goal kyun nahi?** 55' tak 4 goal ho chuke the. 4+ goals by 55' ke baad 60'+ me goal na aana 32% (n=183). Lens 3-1 aage thi, xG 1.43 vs 1.24 (match barabar), Lens ke 3 SOT me se 3 goal (finishing sharp) jabke Troyes ke 5 SOT me 1 goal. Troyes ka 5-game losing skid (Flashscore report). Yeh "no more goals" ka 32% wala hissa tha.
**4. Angers-Marseille: 7 goal, aakhri 10 min me 2 goal.** 7+ goals sirf 2% matches (n=3115); 5+ goals 14%. HT 1-2 par 5+ goals 48%, away jeet 64% (n=89). Marseille xG 2.71 vs 2.21, SOT 8-3, 21 shots. 75' Angers penalty ne 2-3 kiya to Marseille ne 83', 85' me 2 counter. Late goals 85'+: 32%. Pre-match odds dump me nahi.
**5. Le Havre-Auxerre: favourite (2.31) kyun haari, 1-0 HT, Under 2.5?** Home fav 2.2-2.5: jeet 45%, haar 28%, draw 27% (n=417). HT 0-1 par home fav 2.1-2.6: jeet 16%, haar 49% (n=93). Auxerre ka xG 2.70 vs 1.40 (SOT 6-6): xG Auxerre ke haq me tha, pre-match odds ne Le Havre ko fav (2.31) rakha, xG data ulta tha. Last 10 min: 80' goal. Under 2.5 HT 0-1 -> FT Under 2.5 = 53% (n=1144); is match me 4 goal hue (2 baad me).
**6. Paris FC-Rennes: 7 goal, 97' goal, 2 baar comeback phir haar.** xG 3.62-3.35 (donon bahut high), shots 19-12. Penalty 3 (Rennes) + 1 (Paris FC): 4 penalties se 4 goal. HT 2-1 par 5+ goals 47%, 80'+ goal 50%, home jeet 72%, 2-2 FT sirf 17% (n=109). 90+ minute goal: ~21% matches me aakhri minute me goal. "2 baar comeback" ka matlab Rennes ke 3 penalty goals the, Paris FC ke 9 SOT aur xG 3.62.
**7. Lyon-Nice 2-1: red card ke baad 2-2 kyun nahi?** Lyon ke 10 aadmi (70'), leading 2-1 at 70' par: jeet 78%, 2-1 hi rehna 44%, dobara goal 32% (n=235). Nice ne 12 shots/5 SOT/xG 1.55 banaye, 2nd half me goal nahi aaya; 90+3' par Wahi ka goal offside se disallow hua. (Red card: Flashscore me 70' par Nakamura 'Serious foul' — team Lyon samjha, pakka nahi.) Poore match ka xG barabar tha (1.51-1.55).

**Naye rules (data, 3 leagues):**
1. **Strong fav (<1.60) HT par peeche = 32% jeet / 31% draw / 37% haar.** Live me "fav comeback" bet sirf odds >=2.6 aur xG fav ke haq me ho to.
2. **Home fav 2.2-2.5 sirf 45% jeetta hai, 28% haarta hai** — "home fav" ka label pakki jeet nahi. HT 0-1 par to 16% jeet. 
3. **HT 0-1 par 61% away jeet, 23% me 4+ goals.** Home team ka 0-1 se comeback 13% hi.
4. **Aakhri 10 min (81'+) me 2+ goal sirf 8%; 85'+ goal 32%; 90'+ goal 21%.** PSG, Marseille, Paris FC teeno "bahut late goals" wale matches the, par rule nahi.
5. **HT 2-1 / 1-2: 5+ goals 47-48%.** Aise matches me Over 3.5 value ho sakta hai (live odds dekh ke), Under nahi.
6. **4+ goals by 55' ke baad 60'+ me goal na aana 32%** — "match khatam" rule nahi, 68% me aur goal aata hai.
7. **10 aadmi wali team 2-1 aage ho (70'): 78% jeet.** Red card ke baad "comeback draw" par bet na lagao jab tak opposition xG >2 na ho.
8. **Process vs natija:** Lille (xG 2.17), PSG (xG 2.69), Auxerre (xG 2.70) — xG batata hai kaun behtar tha, lekin finishing/penalty/late goals se natija badal sakta hai. Result dekh ke rule mat banao.
