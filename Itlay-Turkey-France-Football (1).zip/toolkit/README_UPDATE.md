# Toolkit — match ke baad master update kaise karein (nayi chat ke liye)

Sab files master artifact me `toolkit/` folder me hain: https://claude.ai/artifact/V9ANdFV9biPvewqAyiLrEa

## Step 1 — files lao
1. Artifact `read` (url ke saath) se page parho (chhota page — poora parhna zaroori hai, warna publish refuse hota hai). Usi read se `index.html` ki saved copy ka path milta hai.
2. Artifact `read` me `paths` = `toolkit/` ki saari files **aur** `manifest.json` + saari `data/*.txt` (list: `action: "list"`, `scope: "files"`). Sab ek work folder me rakho: toolkit files folder ke root me, aur `index.html`, `manifest.json`, `data/` ko `hub2/` ke andar (`hub2/index.html`, `hub2/manifest.json`, `hub2/data/...`).
3. Scripts `.py.txt` naam se rakhe hain — `.py` kar do: `for f in *.py.txt; do mv "$f" "${f%.txt}"; done`
4. `pip install pandas numpy openpyxl markdown --break-system-packages`
5. **xlsx dobara banao** (artifact xlsx nahi rakh sakta, isliye databook `data/*.txt` me hai): `python3 rebuild_xlsx.py hub2` → teeno `*_MASTER_data*.xlsx` ban jaati hain (test kiya: bilkul same rulebook/data nikalta hai).

## Step 2 — naye matches add karo
`python3 add_match.py <seriea|france|turkey> '<json>'` — har match ke liye ek JSON (Date, HomeTeam, AwayTeam, FTHG, FTAG, HTHG, HTAG, Goal_Minutes "Team:min, ..." + jo stats/odds milein). Team naam bilkul databook wale (tool galat naam ya score/minute mismatch par ruk jata hai, duplicate skip karta hai). User Flashscore link de to `"Match_Link"` zaroor daalo; odds aur xG bhi.
Purani row theek karni ho: `python3 add_match.py <league> --update '{"Date":"2026-10-11","HomeTeam":"Como","AwayTeam":"Roma","HS":19}'` (sirf diye gaye columns badalte hain).

## Step 3 — sabaq likho
- `dailylog_<SerieA|France|Turkey>.md` — Section 16: naye matches ki table + lessons.
- `postmortem_<...>.md` — Section 15: pre-match pick → live → result → lesson.
- Naya general sabaq ho to `NEW_CHAT_START_HERE.md` ke "0.8 Pichli galtiyon se sabaq" me.

## Step 4 — sab dobara banao
`python3 build_all.py` → registers, teeno rulebooks (Section 0-20, dates/counts automatic) aur `hub2/` (data, rulebooks, manifest).

## Step 5 — publish
1. Artifact publish: `url` = master link, `file_path` = `hub2/index.html`, `root` = `hub2`, `files` = badli hui `data/*.txt` + `rb/*.json` + `manifest.json` + `toolkit/` ki badli md files (dailylog/postmortem/guide). xlsx publish nahi hoti — `data/*.txt` hi databook hai. **Naya artifact kabhi nahi.**
2. Projects `project_write` se `seriea_MASTER_rulebook.md`, `france_MASTER_rulebook.md`, `turkey_MASTER_rulebook.md` replace karo.
