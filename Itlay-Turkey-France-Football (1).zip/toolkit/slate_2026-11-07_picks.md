# Slate 7-9 Nov 2026 — 25 match, gate output (Section 71 rules)

Regime: teeno league ka last-14 avg >= 3.2 → **GOAL-BULLISH har match me**.
Is liye is poore weekend BTTS No, saari Under lines aur Win-to-nil BLOCKED (62-A/62-E/67-D).

## 71-A triggers (sab se mazboot rule)
| Match | Bet | Odds | Venue gap | Overall gap | League subset |
|---|---|---|---|---|---|
| Genoa v Milan (8 Nov 19:00) | Milan win | 1.80 | -0.45 | in band | Serie A 75.8% |
| Eyupspor v Kocaelispor (7 Nov 15:30) | Kocaelispor win | 1.85 | -0.05 | in band | Super Lig 58.6% |

Dono me cell-gate ne NO BET kaha tha → **71-I** ke tahat 71-A upar hai.
Quote karne wala honest number: ~62% (71-J), 67.7% nahi.

## 69-B only (71-A nahi — Ligue 1)
| Angers v Nice (8 Nov 21:15) | Nice win @2.05 | venue gap +0.40 | 69-B Ligue 1 55.0% | 71-B: 71-A Ligue 1 me nahi |

## Cell-gate LEAN (71-F pass: odds >= min odds)
| Samsunspor v Konyaspor (7 Nov 18:00) | Samsunspor win @2.40 | min 2.39 | cells 7/0 | chance 44%/51% | edge +6%/+23% |
| Le Havre v Lorient (8 Nov 21:15) | Lorient win @2.50 | min 2.35 | cells 8/0 | chance 45%/48% | edge +12%/+20% |

## 69-C chetawni (away fav magar venue gap < -0.5 → away win par bet NAHI)
Parma v Bologna (Bologna @1.80, gap -0.85) · Monza v Atalanta (Atalanta @2.05, gap -0.65) · Fiorentina v Juventus (Juventus @2.10, gap -0.60)

## NO BET (17)
Cagliari-Frosinone, Torino-Lecce, Parma-Bologna, Auxerre-Paris FC, Galatasaray-Amedspor, Goztep-Buyuksehyr,
Roma-Sassuolo, Napoli-Lazio, Monza-Atalanta, Inter-Como, Fiorentina-Juventus, PSG-Troyes, Rennes-Lille,
Brest-Lyon, Le Mans-Monaco, Lens-Marseille, Rizespor-Erzurumspor, Corum-Fenerbahce, Alanyaspor-Trabzonspor, Besiktas-Genclerbirligi
