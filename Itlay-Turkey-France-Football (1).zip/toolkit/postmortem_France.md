## 15. Post-mortem — 16 Oct 2026: Le Mans 0-3 Toulouse (HT 0-0)

- **Pre-match odds (bet365):** 3.00 / 3.50 / 2.25; O2.5 1.666 / U2.5 2.20; Under 3 (Asian) 1.80; BTTS Yes 1.533 / No 2.375. **Neighbour search (Ligue 1 ±4, n=100):** H 29%, D 27%, A 44%; ≤2 goal 51%, exactly 3 23%, 4+ 26%; BTTS 51%.
- **Hamari pick (post):** Under 3 Asian @1.80 (zone 5/10, coin-flip ke qareeb) → ↩️ **refund** (exactly 3 goal). BTTS No @2.375 ko hum ne "~42%, value nahi" kaha tha → asal me **BTTS No jeeta**.
- **Kya hua:** 1st half 0-0. 46' Russell-Rowe (Donnum assist) 0-1, 59' Donnum 0-2, 75' Tengstedt ka goal offside, 87' Tengstedt (Casseres) 0-3. Le Mans ne 61' par 3 subs ek saath kiye (attack ke liye).
- **Stats:** xG 0.95 – 1.81; shots 11 – 13; **on target 1 – 5**; xGOT 0.16 – 3.19; big chances 2 – 2 (Le Mans dono miss, Toulouse dono score); possession 53 – 47%; crosses 35 – 4 (Le Mans ke sirf 7 accurate); corners 2 – 2; fouls 15 – 9.
- **BTTS kyun nahi hua:** Le Mans ke 11 shots me sirf **1 on target** (xGOT 0.16) — 35 crosses, zyada tar bekaar. Data: home SOT ≤1 → home goal nahi karti **75%** (n=55); HT 0-0 → BTTS No **74%** (Ligue 1, n=272). Away 0-2 at 60' → peeche wali home team goal karti hai sirf 43%. **Aam natija.**
- **87' goal kyun:** 0-2 ke baad Le Mans ne 3 subs (61') aur crosses se poora attack kiya → peeche jagah khuli, Toulouse ne counter par goal kiya (75' bhi offside goal tha). Data: 2 goal lead at 80' → 81'+ goal 39% (n=191), aur un me se ~50% goal aage wali team ka. Yaani **coin-flip ke qareeb, surprise nahi**.
- **Hamari galti:** pre-match me BTTS No ko sirf season form (Le Mans 6/6 BTTS) se reject kiya. Pre-match ke liye yeh theek tha, lekin **live HT 0-0 par BTTS No ~74%** ho jata hai — HT par check karna chahiye tha.
- **Lessons:**
  1. **HT 0-0 → BTTS No ~74-76%.** Live HT par BTTS No @1.40+ ho to value; @1.80+ mile to strong.
  2. **Shots on target dekho, shots nahi:** team ke SOT ≤1 (75' tak) → us team ka goal na karna ~75%. Crosses zyada aur accuracy kam = khatra kam.
  3. **2 goal lead + peeche wali team 3 subs/all-out attack** → late goal ka chance ~40%, aur aadha aage wali team counter se karti hai. "Peeche wali team goal karegi" par bharosa mat karo.
  4. Under 3 Asian ne refund diya: Asian lines ka push faida deta hai jab 3 goal bohat mumkin ho (23%).

### Pichla (9 Oct): Lens 2-1 Lyon — pick Under 3.5 @1.65 ✅ (Section 16 log).
