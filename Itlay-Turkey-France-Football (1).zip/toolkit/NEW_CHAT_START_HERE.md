# NEW CHAT — START HERE (Itlay-Turkey-France-Football)

**Last updated: {TODAY}.** Har nayi chat prediction se pehle yeh page poora parhe aur neeche ke steps isi tarteeb se kare.

## ⛔ LAZMI RULE: PREDICTION SE PEHLE 3 BAAR POORA RECHECK (user ka hukm, 17 Oct 2026)
**Koi bhi prediction, pick ya post tab tak nahi dena jab tak neeche ke teeno round poore na hon aur koi galti na bache.** Ek bhi round fail ho → pehle theek karo, phir dobara teeno round. Jawab ke aakhir me hamesha ek line likho: **"✅ 3x recheck: data · rules · maths — sab theek"** (ya kya fail hua aur kyun "No bet").

**Round 1 — Data (sab kuch parho):**
1. Is guide ka har section + league rulebook ke Sections 1-3, 10, 18-23 (khaas kar **22 POWER RULES** aur **23 PRO RULES**).
2. Databook: dono teams ke is season ke saare matches (form, goals, clean sheets, pichle 5 ke points), H2H halka.
3. Model search (±4, **n ≥ 50**, teeno leagues ka bara bucket bhi), O2.5 bucket.
4. Screenshot ke **saare** odds (1X2, O/U, BTTS, AH, DC) — kuch saaf na ho to poochho.
5. **Web se team news:** injuries/suspensions (khaas kar defenders, keeper, main striker), Europe midweek match.

**Round 2 — Rules (har rule se milao):**
1. ✅ rules lagte hain? A1, O1, D1 (Section 22.1), N1, N2 (Section 23.1), away fav 1.30-1.49 / 1.70-1.89 (neeche Section 4). Live ho to **Section 24 category row**.
2. ❌ **Har trap ek-ek karke check:** home fav 1.50-1.80 · "home value" · Under 2.5 value · Ligue 1 away value · longshot (<25%) · hot-form underdog · choti team vs bari · O2.5 ≤1.45 + BTTS Yes ≤1.40 ke khilaf Under · n < 50 bucket · defence-collapse team par +0.5 · early red card.
3. "Pichli galtiyon se sabaq" (neeche) me se koi galti dobara to nahi ho rahi?
4. Live ho to: sahi minute/score ki row (Section 19, 22.3 jackpot table), HT 0-0 → BTTS No ~74%, SOT ≤1 team.
5. User ki shartein: odds 1.80+ · top 2 score · 50-word English post · Roman Urdu.

**Round 3 — Maths aur facts (har number dobara):**
1. p (chance), fair odds = 1/p, value = odds × p − 1 — calculator/code se, andaze se nahi.
2. n ≥ 50? Value ≥ +5%? Strong score (Section 23.4) kitna?
3. **Post ki har baat** (form, goals, injuries, numbers) data/source se milao — jo verify na ho woh post me nahi jayegi.
4. Kahin "pakka / guarantee / lose nahi hogi" to nahi likha? (Hamesha mana.)

**Faisla:** teeno round theek → Strong / Lean likho. Kahin bhi shak → **"No bet"** (yeh bhi sahi jawab hai).

## 0. Master data kahan hai
- **Master artifact (hamesha latest):** https://claude.ai/artifact/V9ANdFV9biPvewqAyiLrEa — teeno leagues ki databook + rulebook ek hi jagah.
  - Artifact tool se `read` karo (url ke saath). Data files: `manifest.json`, `data/<league>__<sheet>.txt` (tab-separated; season sheets `2023-24`…`2026-27`, plus `Late_Goals_81plus`, `Comebacks`, `Score_Patterns`), rulebooks `rb/<league>.json`. League keys: `seriea`, `ligue1`, `superlig`.
  - Ek file parhni ho to Artifact `read` me `path` do (jaise `data/seriea__2026-27.txt`).
- Project ke rulebook docs (`seriea/france/turkey_MASTER_rulebook.md`) master ki copy hain. **Project ke xlsx files 29 Sep ke purane hain** — un par bharosa na karo; data master artifact se lo.
- **Bundesliga / Eredivisie** is artifact me nahi — un ka data Germany-Netherland artifact (https://claude.ai/artifact/J2DZNWuxEe16CQEgRFYKT4) me hai; wahan ke rules alag hain, yahan ke % un par mat lagao.
- Total data: {TOTAL} matches (Serie A {SA} · Ligue 1 {L1} · Süper Lig {SL}), results {RESULTS_TO} tak.

## 1. Screenshot / image / stats aaye to pehle yeh nikalo
1. League, home team, away team (databook ke team naam se milao: jaise `Goztep`, `Buyuksehyr`, `Amed Sportif Faaliyetler`, `Çorum FK`, `Paris SG`).
2. Pre-match ya live? Live ho to **minute, score, red cards, shots on target, xG**.
3. Saare odds jo screenshot me hain: 1X2, Over/Under 0.5-6.5, BTTS, Asian handicap, double chance.
4. Kuch saaf na dikhe to user se poochho — **andaza mat lagao**.

## 2. Pre-match check (rulebook sections)
1. **League profile** (Section 1): Serie A low-scoring (avg 2.55, O2.5 48%); Ligue 1 (2.84, 54%) aur Süper Lig (2.81, 53%) zyada open.
2. **Model search** (Section 2): 1X2 odds ko margin hata kar probability banao; **saare** purane matches lo jinki teeno probabilities ±4 points ke andar hon (5-10 nahi). Unka H/D/A, avg goals, Over 0.5-5.5, BTTS, top scores = history answer. Over 2.5 opening odds ka bucket bhi dekho (Section 2.3).
3. **Value signals** (Section 2.6/20, asli odds par profit test 17 Oct): ✅ **away fav 1.30-1.49 (+7%) aur 1.70-1.89 (+10%)** teeno seasons plus. ⚠️ home fav 2.10-2.39 (+5% lekin ek season minus) aur Over 2.5 @2.40+ (+24% lekin ek season −12%) = sirf Lean. Baqi ⚠️/❌ par bet nahi.
4. **Trap check** (Section 3): fav HT par 1 goal peeche → sirf ~20% jeetta, ~50% haarta (away fav ~58%). 1.30-1.49 home fav bhi ~28% nahi jeetta.
5. **Teams** (Section 10): high/low scoring, late goals, trap %. Is season ka form aur pichle 2-3 match (defence collapse? 4+ goals khaye?) dekho.
6. **Live me exact situation** (Section 19): minute + score + fav ki taaqat wali row.
7. **Pattern predictor** (Section 18.2): Over 2.5 opening odds + fav odds se 0-0, 1-1, 5+, 70' ke baad dead, 81'+ goal, trap ka asal chance lo.
8. H2H sirf halka weight.

## 3. Live check
- **15-20'** → Section 6 (20' par 0-0 = Under ki taraf; dog 1-0 aage = BTTS ~81%, Over 2.5 ~72%).
- **45-80' lead / equalizer** → Section 7 (65' par dog 1 aage → fav ka goal ~49%; 80' par level → aur goal sirf ~38%).
- **Comeback** → Section 8 (peeche wali team fav ho to chance double).
- **81'+ goal / 70' ke baad dead** → Section 9. **95% late-goal zone maujood nahi** — sab se ooncha ~45-48%.
- **HT 0-0 / 1st half burst** → Section 5.
- **Early red card** (15' se pehle) → pre-match model reset; Section 14.1.
- **Live xG / shots on target** → Section 21.2-21.3 (total SOT 0-4 = Over 2.5 sirf ~8%; total xG 3.5+ = ~85%).
- **⭐ PEHLI TARJEEH (Section 22.6):** har live screenshot par sab se pehle yeh 5 haalat dhoondo — #1 strong fav (<1.60) jaldi 1 goal peeche → **Draw No Bet fav @2.00+** (Bologna 1-0 Inter misaal, 17 Oct). Mile to yahi pick, saath me lose-save/hedge ka option.
- **🔄 COVER COMBO (Section 22.7):** har match me 2 bets dikhao jo ek doosre ko bachayein (jaise Draw + BTTS No, ratio 2:3), har score ka rupees table, ~kitne % baar profit, aur 'dono haarein' ka chance. Koi combo 100% profit nahi deta — yeh saaf likho.
- **🔴 LIVE SYSTEM (Section 24):** pre-match category (fav taaqat × O2.5 odds) → 20' row (24.2) → HT row (24.3) → match ki category, Under/Over, BTTS, top 2 score. **0-0 signals** Section 24.5.
- **Jackpot / live value** → Section 22.3 table: har haalat ka asal % aur "sirf is se upar lo" odds. Live odds us se kam → bet nahi.
- **HT 0-0** → BTTS No ~74-76% (Le Mans sabaq); team ke SOT ≤1 → us ka goal na karna ~75%.

## 3b. User poochhe "yeh aisa kyun hua?" (goal kyun nahi aaya, BTTS kyun, 1-1 kyun, late goal kyun)
1. Match ki situation Section 21.1 me dhoondo (jaise "0-0 HT → Under 2.5", "1-1 at 80' → aur goal"). League aur teeno ka % do.
2. Stats dekho: xG (21.2), shots on target (21.3), big chances, red card, subs (top players 60-75' me nikle?).
3. Saaf likho: **"aam natija"** (60%+ cases me aisa hota hai) ya **"surprise"** (<25%). Surprise par rule mat badlo.
4. Jawab table me do: Match | Sawal | Purane matches % | Stats | Faisla. Phir 3-5 "agle matches ke sabaq". Section 16 ke "16 Oct" wale table jaisa.
5. Yeh sab dailylog me save karo (Section 7 neeche).

## 4. Bet chunne ka faisla (Section 11 + **22 POWER RULES** + **23 PRO RULES**)
**✅ Tested strong rules (asli odds par profit, har season plus):**

| Rule | Kab | ROI |
|---|---|---|
| A1 | Away value ≥ +5% (model search), sirf Serie A + Süper Lig | +14% |
| O1 | Over 2.5 value ≥ +5%, sirf Serie A | +26% |
| D1 | Draw value ≥ +5%, sirf Süper Lig | +10% |
| N1 | Fav ke pichle 5 me ≤4 pts aur opponent 3+ pts behtar → fav | +16% |
| N2 | Aug-Oct, draw odds ≤ 3.60 → draw | +11% |
| AF | Away fav 1.30-1.49 / 1.70-1.89 | +7% / +10% |

**❌ Traps (har season minus) → no bet:** home fav 1.50-1.80 · "home value" signal · Under 2.5 value · Ligue 1 away value · longshot (<25% chance) ki jeet · hot-form underdog · choti team vs bari team · apna simple Elo model.

**Faisla ka tareeqa:**
1. Chance p nikalo (model search + live grid + team news); market se bara farq ho to wajah dhoondo.
2. Fair odds = 1/p. Value = offered × p − 1.
3. **Bet sirf tab:** value ≥ +5%, n ≥ 50, rule ✅ list me, koi trap nahi. (Home par value dikhe to bhi **no bet** — T2 trap.)
4. **Strong score (Section 23.4):** 4-5 = Strong (2%), 2-3 = Lean (1%), ≤1 = No bet.
5. User 1.80+ chahta hai, lekin 1.80+ par koi market pass na ho → saaf "No bet" ya Lean likho; ✅ picks ko double banane ka option do. Zabardasti pick mat do.
6. Kabhi "pakka / guarantee / lose nahi hogi" mat kaho. 1.80 = ~55%; "never lose" maths me mumkin nahi.

## 5. 3-baar check (lazmi — poora tareeqa upar ⛔ LAZMI RULE me)
1. **Check 1:** rulebook ke upar wale sections parhe? League, odds, trap, team, live grid.
2. **Check 2:** kuch miss to nahi? Red card, **line-up/injury (khaas kar defenders/keeper — web se check karo)**, is season ka form, sahi minute ka row, live odds.
3. **Check 3:** maths — p, fair odds, value, n. Ek bhi fail → no bet.

## 6. Jawab ka format
- Market + odds, chance %, fair odds, value, **Strong / Lean / No bet**, 2-3 line "kyun" (numbers ke saath).
- **Har pick ke saath 50-word English post** (user ki standing shart) — sirf verified facts.
- **Har match me Cover Combo (Section 22.7)** bhi do: 2 bets + stake ratio + har score ka hisaab.
- Aakhir me: **"✅ 3x recheck: data · rules · maths — sab theek"**.
- **User ki shart (17 Oct 2026):** har match me **sirf 2 sab se mumkin final score** do (jaise "1-1 ya 2-1"), dono ka % aur mila kar %. Lekin **"in ke elawa kuch nahi hoga" kabhi mat kaho** — top 2 score aam taur par sirf ~25-35% hote hain. Saath me ek zyada-chance wali market (jaise Under 3.5 ~70%) do.
- Roman Urdu me jawab; seedha, chhota.

## 7. Match khatam hone ke baad (master update)
1. Master artifact ke `toolkit/` folder me **README_UPDATE.md** hai — usi ke 5 steps follow karo (files lao → `add_match.py` → dailylog/postmortem md me sabaq → `python3 build_all.py` → usi url par publish + project rulebooks replace).
2. **User Flashscore link de to `Match_Link` column me zaroor daalo** (naye match ke JSON me `"Match_Link": "<url>"`; purane match ke liye `python3 add_match.py <league> --update '{"Date":..,"HomeTeam":..,"AwayTeam":..,"Match_Link":..}'`). User ke diye stats (shots, SOT, corners, cards, fouls, xG) bhi `--update` se daalo.
3. **Odds bhi save karo** (B365H/D/A, B365>2.5, B365<2.5) jab user screenshot me de — 2026-27 ke bohat matches ke odds databook me nahi hain, aur bina odds model search nahi hota.
4. Yeh tools har cheez khud check karte hain (galat team naam, score vs goal minutes, duplicate) aur poori rulebook dobara banate hain — haath se numbers mat likho.
5. **Naya artifact kabhi mat banao**; hamesha master url par publish.

## Pichli galtiyon se sabaq
- Eyüpspor +0.5 (12 Oct): model search me edge zero tha, 9' red card aaya, aur Eyüpspor ne 2 match me 12 goal khaye the → **edge zero ho to no bet; defence collapse wali team par "+0.5" mat lagao.**
- BTTS No jab dog 2 goal peeche ho: ~59% baar dog goal kar deta hai → aisa BTTS No mat lagao.
- Purani rulebook ka "70' tak 0-0 = 57-75% late goal" galat tha; asal ~29-35%.
- Sassuolo 1-1 Milan (11 Oct): Over 2.5 diya tha, Under aaya. Serie A ka Over base ~48% hai, total xG 2.37 tha aur HT 0-0 (→ 84% Under) → **Serie A me bina odds-value ke Over 2.5 mat do; HT 0-0 par Over hedge karo.**
- Çorum 2-1 Rizespor (16 Oct): 60' par 1-1, Çorum ne 80' par goal kiya. Süper Lig me 60' par 1-1 → aur goal **64%** (n=135), home fav ho to agla goal **64% home ka**. Hamari Under 3.5 @1.56 jeeti, Draw @2.40 haari → **level score + home fav = draw par bara stake mat lagao; "aur goal" zyada mumkin side hai, lekin Over 2.5 sirf 1.60+ odds par.**
- Frosinone 4-2 Sassuolo (16 Oct): Under 3.5 @1.80 diya, 6 goal aaye. Market O2.5 @1.40 de raha tha, Sassuolo ka defender Leysen bahar tha, aur hum ne n=25 ke chhote bucket par bharosa kiya (bara bucket Under 3.5 sirf 53% = no bet). → **O2.5 opening ≤1.45 ho to Under mat do; n < 50 bucket par pick nahi; injuries lazmi check karo.**
- "Bohat goal ho gaye to 60' ke baad goal nahi aata" — **galat**: 60' tak 5+ goal wale 75 matches me 71% baar aur goal aaya. Aisa rule mat banao.
- Le Mans 0-3 Toulouse (16 Oct): BTTS No pre-match reject kiya (Le Mans 6/6 BTTS), lekin HT 0-0 tha aur Le Mans ke sirf 1 SOT the. → **Live HT 0-0 par BTTS No ~74% — HT par hamesha check karo; jis team ke SOT ≤1 hon woh ~75% baar goal nahi karti.**
- Como 0-0 Roma: red card ke bawajood 0-0 → **red card = goals nahi; 10 aadmi wali team defend karti hai.**

---
## ⛔ 30 OCT: Section 63 FINAL PICK PROTOCOL sab se upar. Har pick se pehle `toolkit/pick_gate.py.txt` (rename .py) chalao; detail `toolkit/FINAL_PICK_PROTOCOL.md`.
