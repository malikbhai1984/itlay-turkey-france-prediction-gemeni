## 22. POWER RULES — data + odds dono saath hon (backtest se tested, 17 Oct 2026)

**Yeh section kyun:** user chahta hai ke sirf woh markets di jayein jahan **databook aur odds dono support karein**, traps se bacha jaye, aur "jackpot" (kam loss, zyada profit) wali haalat pehchani jayein. Har rule ko **walk-forward backtest** se check kiya gaya: har match ke liye sirf us se pehle ke matches dekhe gaye (future ka data use nahi hua), aur asli bet365 odds par flat stake profit/loss gina gaya. 2024-25 se 2026-27 tak ~2,000 matches, teeno leagues.

**Pehli sachai:** har market par andha-dhund bet = **−7.1% ROI** (n=9,905 bets). Yeh bookmaker ka margin hai. Profit sirf un rules me hai jo neeche ✅ hain — aur woh bhi lambe arse me, har match me nahi.

### 22.1 ✅ Strong rules (dono seasons me plus)

| Rule | Kab lagao | n | Hit % | Avg odds | ROI 2024-25 | ROI 2025-27 | ROI total |
|---|---|---|---|---|---|---|---|
| **A1 — Away value** | Model search (±4, n≥50) me away ka chance × away odds ≥ 1.05 (value ≥ +5%), **sirf Serie A aur Süper Lig** | 179 | 58% | 2.42 | +9.1% | +19.3% | **+14.4%** |
| **O1 — Over 2.5 value** | Model search (O2.5 implied ±3, n≥50) me Over value ≥ +5% (aam taur par O2.5 odds 2.30+), **sirf Serie A** | 65 | 51% | 2.50 | +0.7% | +32.2% | **+26.4%** |
| **D1 — Draw value (Süper Lig)** | Model search me draw value ≥ +5%, **sirf Süper Lig** (draw odds ~3.6-4.5) | 194 | 29% | 4.05 | +9.4% | +12.1% | **+10.5%** |
| A1 + O1 mila kar | | 244 | 56% | 2.44 | +8.1% | +23.9% | +17.6% |

**Double support ka matlab (har pick ke liye):** (1) market ke odds ka bucket (Section 2) value de, (2) model search ka n ≥ 50 ho, (3) rule upar wali list me ho (league bhi sahi ho), (4) koi trap (22.2) na ho, (5) team news (injury/suspension) us side ko kamzor na kare. **Paanchon haan → "Strong" pick.** Ek bhi na → "Lean" ya "No bet".

### 22.2 ❌ TRAPS — yahan odds dhoka dete hain (dono seasons me minus)

| Trap | n | Hit % | ROI 2024-25 | ROI 2025-27 | Kya karna hai |
|---|---|---|---|---|---|
| **T1 — Home favourite 1.50-1.80** | 288 | 57% | −5.0% | −8.8% | Is range ke home fav ko back mat karo. Market inhe zyada price karta hai |
| **T2 — "Home value" (model kehta hai home me value)** | 101 | 44% | −20.6% | −14.9% | Hamara home-value signal **galat** nikla. Home par value dikhe to bhi **no bet** |
| **T3 — Under 2.5 value ≥ +5%** | 28 | 25% | −10.1% | −100% | Jab model Under me bari value dikhaye, aksar match khula nikalta hai (Frosinone 4-2 jaisa). **Under 2.5 value par bet nahi** |
| Ligue 1 away value | 83 | 51% | — | — | Ligue 1 me A1 kaam nahi karta (−10.3%) |

**Market-direction trap (Frosinone sabaq):** jab O2.5 ≤ 1.45 **aur** BTTS Yes ≤ 1.40 ho, market "khula match" keh raha hai — us ke ulat Under/BTTS No mat lagao.

### 22.3 💰 JACKPOT table — live haalat (teeno leagues, 3,234 matches, goal minutes ke saath)

**Jackpot ka asli matlab:** aisi haalat jahan live odds asal chance se **zyada** mil rahe hon. Neeche "fair" = 100/chance, aur **"Sirf is se upar lo"** = fair × 1.05 (5% value). Live odds is se kam hon → **mat lagao**, chahe haalat kitni bhi "jackpot" lage.

| Haalat (fav = pre-match favourite) | Bet | n | Asal chance | Fair | Sirf is se upar lo |
|---|---|---|---|---|---|
| **Comeback:** fav HT par 1 goal peeche | Fav na haare (DC / +0.5) | 469 | 50% | 2.01 | **2.11** |
| | Fav jeete | 469 | 20% | 4.94 | 5.18 |
| | FT draw | 469 | 29% | 3.40 | 3.57 |
| **Strong fav (<1.60)** HT par 1 peeche | Fav na haare | 91 | 66% | 1.52 | 1.59 |
| | Fav jeete | 91 | 34% | 2.94 | **3.08** |
| Strong fav (<1.60) 60' par 1 peeche | Fav na haare | 75 | 57% | 1.74 | **1.83** |
| | Fav jeete | 75 | 25% | 3.95 | 4.14 |
| Fav 60' par 1 peeche | Fav na haare | 450 | 41% | 2.45 | 2.57 |
| Fav 70' par 1 peeche | Fav na haare | 434 | 36% | 2.80 | 2.94 |
| Fav HT par 2 peeche | Fav na haare | 95 | 20% | 5.00 | 5.25 |
| **Level 1-1 / 2-2** at 60' | Aur goal nahi (draw) | 451 | 33% | 3.05 | 3.20 |
| | Fav jeete | 451 | 39% | 2.59 | 2.72 |
| Level 1-1 / 2-2 at 70' | Draw hi rahe | 522 | 46% | 2.18 | 2.29 |
| Level 1-1 / 2-2 at 75' | Draw hi rahe | 546 | 52% | 1.94 | 2.04 |
| Level 1-1 / 2-2 at 80' | Draw hi rahe | 558 | 58% | 1.73 | **1.81** |
| | Fav jeete | 558 | 26% | 3.80 | 3.99 |
| **0-0** at 60' | Koi goal aaye (O0.5) | 615 | 60% | 1.66 | 1.74 |
| 0-0 at 70' | Koi goal aaye / FT 0-0 | 473 | 48% / 52% | 2.07 / 1.94 | 2.17 / 2.04 |
| 0-0 at 75' | FT 0-0 | 409 | 60% | 1.68 | 1.76 |
| 0-0 at 80' | FT 0-0 | 358 | 68% | 1.47 | 1.54 |
| **Last 10 min** — level at 80' | 81'+ goal aaye | 916 | 38% | 2.62 | 2.76 |
| Fav 1 aage at 80' | 81'+ goal aaye | 866 | 42% | 2.41 | 2.53 |
| | Dog barabar kare | 866 | 14% | 6.98 | 7.33 |
| Fav 1 peeche at 80' | Fav barabar ya jeete | 413 | 25% | 4.09 | 4.29 |
| 2+ goal lead at 80' | 81'+ goal aaye | 910 | 41% | 2.43 | 2.55 |
| **Close match** (H aur A dono ≥ 2.40) | FT draw (pre-match) | 455 | 32% | 3.12 | 3.27 |
| Close match, level at 75' | Draw hi rahe | 164 | 59% | 1.69 | 1.78 |

**Jackpot ke hints (kab dhyan do):**
1. **Strong fav (<1.60) peeche ho** → market aksar fav ko zyada saza deta hai. "Fav na haare" ~57-66% hai. Live odds **1.80+** mile to yeh sab se acchi jackpot haalat hai.
2. **1-1 at 80'** → draw ~58%. Live draw odds **1.85+** ho to value (market aksar 2.0+ deta hai jab late goal ka shor ho).
3. **Close match me 75' tak barabar** → draw ~59%; 1.80+ par value.
4. **Last 10 min goal** sirf 38-42% hai — "pakka late goal" kabhi nahi. Is market ko sirf **2.60+** par lo.
5. Comeback **win** (fav jeete) 70' ke baad sirf ~10% — yeh lottery hai, jackpot nahi.

### 22.6 ⭐ PEHLI TARJEEH (user ka hukm, 17 Oct 2026) — har live match me pehle yeh haalat dhoondo
User ne kaha: "next time esi hi bets karwani hain" (Bologna-Inter wali). In haalaton me **value + kam risk** dono hote hain. Har live screenshot par **sab se pehle** yeh list check karo; mile to yahi pick do.

| # | Haalat | Bet (user ki site par kahan) | Asal chance | Sirf is se upar lo |
|---|---|---|---|---|
| 1 | **Strong fav (pre-match <1.60) 15-45' me 1 goal peeche** | **DRAW_NO_BET → fav (neela box)** — draw par paisa wapas | jeet ~38-43%, refund ~34%, haar ~22-26% | **2.00** |
| 1b | Wahi haalat | MATCH_ODDS → underdog ko **Lay (gulabi)** = fav ya draw | ~70-78% | 1.42 (effective) |
| 2 | Strong fav HT par 1 peeche | DRAW_NO_BET fav / Lay dog | na haare ~66% | 1.59 |
| 3 | 1-1 / 2-2 at 80' | Draw | ~58% | 1.81 |
| 4 | Close match (H aur A dono 2.40+) 75' tak barabar | Draw | ~59% | 1.78 |
| 5 | Ek team ka attack band (60'+ par xGOT < 0.2, big chances 0) + total xG < 1.5 | Us team ke khilaf BTTS No / Under (current+0.5) | general data se 8-10 points zyada | data ke fair odds × 1.05 |

**Asli misaal (17 Oct 2026):** Bologna 1-0 Inter (32'). Inter pre-match 1.57. Market Bologna ko ~38% de raha tha, data 22-30%. **Inter DNB @2.16** (1,000 stake: Inter jeete +1,160, draw 0, Bologna jeete −1,000). Inter ne barabar kiya (1-1), user ne loss save (hedge) kar liya. ✅ Haalat #1 ne kaam kiya.

**Zaroori:** yeh "pakki" nahi — haalat #1 me bhi ~22-26% baar fav haarta hai. Lekin DNB ki wajah se 4 me se ~3 baar paisa nahi doobta. Stake 1-1.5%. Goal hone ke baad (barabar) **lose-save / hedge** ka option hamesha batao.

### 22.7 🔄 COVER COMBO — har match me 2 bets jo ek doosre ko bachayein (user ka hukm, 17 Oct 2026)
User chahta hai: **har match me 2 aisi bets dikhao ke ek haare to doosri se profit ho, aur dono pass ho jayen to dono ka profit.** Sachai pehle batao: **koi combo har natije par profit nahi deta** (warna bookmaker ka margin khatam) — lekin aisa combo ban sakta hai jo zyada tar natijon par profit de aur sirf ek kism ke score par haare.

**Tareeqa (har match):**
1. 2 markets chuno jin ke "haar" wale natije **alag** hon (overlap kam), aur jin ka "dono jeet" wala natija bhi mumkin ho.
2. Stake ratio aisa rakho ke **akeli jeet bhi poore stake se zyada laaye**: agar odds o1, o2 aur stake s1, s2 → akeli bet 1 jeete to s1×(o1−1) − s2 > 0, akeli bet 2 jeete to s2×(o2−1) − s1 > 0.
3. Har final score ke liye table do: kaunsi jeeti/haari, rupees me hisaab, aur data se chance. Phir average (EV) aur "dono haarne" ka chance saaf likho.
4. Team form/stats se "dono haarne" wala chance upar ho to stake kam karne ko kaho.

**Tayyar combos (live, data ke mutabiq):**

| Haalat | Bet 1 | Bet 2 | Dono jeetein | Sirf tab dono haarein |
|---|---|---|---|---|
| 0-0 pehle half me (barabar match) | **Draw** (~3.4-3.6) | **BTTS No** (~2.0) — ratio 2:3 | FT 0-0 | 2-1 / 1-2 / 3-1 jaise (BTTS + koi jeete) |
| 0-0, Under/BTTS No ki taraf | **Under 2.5** | **Draw** | 0-0, 1-1 | 2-1, 3-0, 2-2+... |
| Strong fav peeche (haalat #1) | **Fav Draw No Bet** | **Over 2.5 / BTTS Yes** | fav comeback 2-1 | dog 1-0 / 2-0 jeete |
| Fav aage 1-0 (60'+) | **Fav jeete** | **Next goal: dog / Draw** (chhota) | — (hedge) | fav 1-0 → 1-1 → dog aur goal |

**Asli misaal (17 Oct, Newcastle 0-0 Villa, 27'):** Draw @3.55 = 400 + BTTS No @2.00 = 600. EPL data (n=577): 0-0 → **+1,620** (10%) · 1-1/2-2 → **+420** (20%) · 1-0/0-1/2-0 → **+200** (44%) · 2-1/1-2/3-1 → **−1,000** (25%). ~75% baar profit, EV ~+8%.

**Stake:** combo ka kul stake bankroll ka 1-2%. "Dono haarein" ka chance 30% se upar ho to combo mat do.

### 22.4 Stake rule (kam loss, zyada profit)
- **Strong (22.1 rule + double support):** bankroll ka 2%.
- **Jackpot live (22.3, odds ≥ "sirf is se upar lo"):** 1-1.5%.
- **Lean / coin-flip (value 0-5%):** 0.5-1% ya no bet.
- **Trap (22.2):** 0%.
- Ek din me 3-4 se zyada bets nahi; lagatar 3 haar → us din band.

### 22.5 Imandari wali hadein
- Samples chhote hain (65-244 bets). Agle 100+ bets me ROI badal sakta hai — har mahine is backtest ko dobara chalao (`toolkit/backtest_rules.py`).
- League filter (A1 me Ligue 1 bahar, O1 sirf Serie A) data dekh kar chuna gaya — is me thora "luck" shamil ho sakta hai.
- Live table me **live odds hamare data me nahi** — isliye profit sirf tab hai jab aap ke screen ke odds "sirf is se upar lo" se zyada hon.
- Koi rule "pakka" nahi. +14% ROI ka matlab hai 100 bets me ~14 unit profit, aur beech me 5-7 lagatar haar bhi aam hai.

## 23. PRO RULES — bahar ki research + hamare data par test (17 Oct 2026)

**Tareeqa:** professional betting research (favourite-longshot bias, form overreaction, promoted teams, popular-team sentiment, rest days, season phase, Elo/rating models, closing line value) ke har idea ko teeno leagues ke 2023-24 → 2025-26 ke asli bet365 odds par test kiya. **Sirf woh rule "✅" hai jo teeno seasons me plus raha.** Research khud kehti hai ke kai "biases" sirf statistical noise hote hain aur waqt ke saath khatam ho jaate hain — isliye har mahine dobara test karo.

### 23.1 ✅ Naye strong rules

| Rule | Kab | n | Hit % | Avg odds | 23-24 | 24-25 | 25-26 | Leagues |
|---|---|---|---|---|---|---|---|---|
| **N1 — Bad-form favourite (market overreaction)** | Pre-match fav ke **pichle 5 match me ≤4 points**, aur opponent ka form fav se **3+ points behtar** → **fav ko back karo** | 216 | 55% | 2.16 | +10.2% | +21.8% | +17.8% | SA +8%, L1 +7%, SL +28% |
| N1b — Bad-form fav, odds ≥ 1.80 | Fav ke pichle 5 me ≤4 points, fav odds 1.80+ | 386 | 49% | 2.22 | +8.2% | +4.0% | +12.8% | SL +17%, L1 +7%, SA 0% |
| **N2 — Early-season draw** | **Aug-Oct** ke match, **draw odds ≤ 3.60** → draw | 489 | 33% | 3.38 | +17.9% | +1.7% | +11.1% | SA +24%, SL +4%, L1 +2% |
| N2b — Early-season draw (sab) | Aug-Oct, koi bhi draw | 879 | 28% | 3.86 | +3.9% | +4.9% | +6.1% | SA +8%, L1 +6%, SL −1% |

**Kyun kaam karta hai:**
- **N1:** log aur bookmaker taaza buri form (2-3 haar) par zyada react karte hain; achhi team ka odds lamba ho jata hai jab ke asli taaqat kam nahi hui. Ulti baat bhi sach hai: **hot-form underdog ko back karna −34%** (trap).
- **N2:** season ke shuru me teams ka andaza kam hota hai, aur barabar ki teams ke match me draw zyada hote hain jitna market sochta hai. **Abhi October hai — yeh rule is waqt lagta hai**; November se band (Nov-Feb draw −5.5%).

### 23.2 ❌ Naye traps (har season minus)

| Trap | n | ROI | Matlab |
|---|---|---|---|
| **Longshot (jeet ka chance < 25%)** ko jeet par back karna | 1,730 | **−24% se −36%** | Favourite-longshot bias: bari odds wali team par paisa sab se zyada doobta hai. "Upset jackpot" ka shauq = loss |
| **Hot-form underdog** (dog ke pichle 5 me 12+ points) | 110 | **−34%** | Form dekh kar dog par mat jao |
| **Small team vs big team** (Juve/Inter/PSG/Galatasaray waghaira ke khilaf) | 1,093 | **−32%** | Choti team ki jeet ka shauq loss deta hai |
| Promoted team ke khilaf bet | 584 | −5% / −7% | Koi edge nahi |
| "Zyada aaram ke din" (sirf league dates se) | 195 | −11% / −24% | Cup/Europe ke match data me nahi — is par bharosa mat karo |
| **Simple Elo rating model** (value ≥ 10%) | 881 | **−8%** | Market simple models se zyada smart hai — apna "rating" bana kar market ko harana mushkil hai |

### 23.3 Professional checklist (sources se — hamare data me test nahi ho sakta, lekin zaroori)

1. **Closing Line Value (CLV):** jo odds aap ne liye, woh kickoff se pehle ke aakhri odds se behtar the? Lambe arse me **CLV hi asli skill ka sabse saaf signal hai**, result nahi. Har bet ka entry odds aur kickoff odds note karo; agar aksar aap ke odds kickoff tak girte hain (aap ne 2.20 liya, band 2.05 par hua) to aap sahi side par ho.
2. **Line movement:** match se pehle odds kisi side par **tezi se girein** (jaise 2.30 → 2.00) to aksar injury/line-up ki khabar hoti hai — us ke **khilaf** bet mat karo.
3. **Line-up 60 minute pehle:** main striker / goalkeeper / 2+ defenders bahar → model ka chance badlo. Frosinone-Sassuolo (defender bahar → 6 goal) yaad rakho.
4. **Europe/Champions League midweek:** fav ne 3 din pehle Europe khela ho aur rotation ho → fav ki jeet thori kam. (Hamare data me cup/Europe dates nahi, isliye % nahi diya.)
5. **Motivation (season ke aakhir me):** relegation se bachne wali team vs kuch na khelne wali team — market aksar late react karta hai. (April-May me dhyan.)
6. **Bankroll:** flat stake 1-2%; "Kelly" formula ka sirf aadha/chautha hissa — kabhi poora nahi.

### 23.4 Final faisla — ab har pick aise banegi (Strong score)

Har market ke liye points jodo:
- +2: Section 22/23 ka ✅ rule lagta hai (A1, O1, D1, N1, N2)
- +1: model search value ≥ +5% aur n ≥ 50
- +1: team news us side ke haq me (opponent ke key players bahar)
- +1: odds hamari side par gir rahe hain (positive CLV)
- −3: koi bhi trap (22.2 / 23.2) lagta hai
- −1: hamari side ke key players bahar / Europe midweek rotation

**4-5 = Strong (2% stake) · 2-3 = Lean (1%) · ≤1 = No bet.** "Pakka" kabhi nahi — Strong pick bhi ~40-45% baar haar sakti hai.

## 24. LIVE SYSTEM — 15-20' aur HT par match ki category pehchano (17 Oct 2026)

**Maqsad:** match shuru hone ke 15-20 minute baad, aur phir half-time par, pata lagana ke match kis taraf ja raha hai aur score kya ho sakta hai. Data: teeno leagues ke 3,100+ matches jin ke goal minutes aur pre-match odds dono hain. **Score hamesha "fav-dog" order me** (pehla number favourite ka).

**Tareeqa (3 qadam):**
1. **Pre-match category** do cheezon se: (a) favourite ki taaqat — Strong (<1.60), Medium (1.60-2.19), Barabar (fav 2.20+); (b) Over 2.5 opening odds — Goals (≤1.70), Normal (1.71-2.05), Tight (>2.05).
2. **20' par** score dekh kar neeche 24.2 ki row lo.
3. **HT par** score dekh kar 24.3 ki row lo — yahan tasveer sab se saaf hoti hai.

**Sachai:** 20' par sirf andaza behtar hota hai; HT par kai categories me 80-90% wale signals milte hain (jaise HT 0-0 + Normal/Tight → Under 2.5 81-88%). Lekin **"pakka" kabhi nahi** — 90% wali row bhi 10 me se 1 baar ulti hoti hai. Har row ka bet sirf tab jab live odds "fair" (100/%) se 5% zyada hon.

### 24.1 Pre-match category (kick-off se pehle)
| Category | Score | n | Fav jeete | Draw | Fav haare | Under 2.5 | 4+ goal | BTTS | FT 0-0 | Top 2 score (fav-dog) |
|---|---|---|---|---|---|---|---|---|---|---|
| Strong fav (<1.60) + Goals (O2.5 <=1.70) | — | 501 | 73% | 17% | 10% | 34% | 44% | 56% | 3% | 2-0 (11%), 2-1 (11%) |
| Strong fav (<1.60) + Normal (O2.5 1.71-2.05) | — | 253 | 69% | 22% | 9% | 48% | 29% | 48% | 5% | 2-0 (15%), 1-0 (14%) |
| Strong fav (<1.60) + Tight (O2.5 >2.05) | — | 33 | 64% | 30% | 6% | 61% | 18% | 42% | 12% | 2-1 (21%), 2-0 (21%) |
| Medium fav (1.60-2.19) + Goals (O2.5 <=1.70) | — | 295 | 58% | 21% | 21% | 42% | 37% | 55% | 7% | 2-1 (12%), 1-0 (10%) |
| Medium fav (1.60-2.19) + Normal (O2.5 1.71-2.05) | — | 770 | 52% | 29% | 19% | 52% | 24% | 53% | 10% | 1-1 (14%), 1-0 (12%) |
| Medium fav (1.60-2.19) + Tight (O2.5 >2.05) | — | 350 | 52% | 32% | 16% | 57% | 23% | 50% | 10% | 1-0 (16%), 1-1 (15%) |
| Barabar (fav 2.20+) + Goals (O2.5 <=1.70) | — | 87 | 40% | 30% | 30% | 45% | 31% | 61% | 6% | 1-1 (14%), 2-1 (10%) |
| Barabar (fav 2.20+) + Normal (O2.5 1.71-2.05) | — | 397 | 40% | 29% | 31% | 49% | 28% | 57% | 8% | 1-1 (14%), 1-0 (9%) |
| Barabar (fav 2.20+) + Tight (O2.5 >2.05) | — | 419 | 42% | 29% | 28% | 57% | 20% | 49% | 11% | 1-0 (13%), 1-1 (13%) |

### 24.2 20' par — category + score (n ≥ 30 wali rows)
| Category | Score | n | Fav jeete | Draw | Fav haare | Under 2.5 | 4+ goal | BTTS | FT 0-0 | Top 2 score (fav-dog) |
|---|---|---|---|---|---|---|---|---|---|---|
| Strong+Goals | 0-0 | 280 | 69% | 19% | 12% | 47% | 31% | 49% | 6% | 1-0 (15%), 2-0 (13%) |
| Strong+Goals | dog +1 (0-1) | 33 | 42% | 39% | 18% | 12% | 73% | 94% | 0% | 2-2 (21%), 2-1 (12%) |
| Strong+Goals | fav +1 (1-0) | 130 | 86% | 10% | 4% | 25% | 48% | 56% | 0% | 3-0 (14%), 2-0 (13%) |
| Strong+Goals | fav +2 | 37 | 97% | 0% | 3% | 3% | 78% | 49% | 0% | 4-0 (19%), 3-0 (14%) |
| Strong+Normal | 0-0 | 152 | 62% | 26% | 12% | 66% | 12% | 39% | 8% | 2-0 (19%), 1-0 (17%) |
| Strong+Normal | fav +1 (1-0) | 65 | 88% | 9% | 3% | 29% | 42% | 45% | 0% | 2-1 (15%), 1-0 (14%) |
| Medium+Goals | 0-0 | 175 | 55% | 25% | 20% | 56% | 21% | 43% | 12% | 2-1 (14%), 1-0 (13%) |
| Medium+Goals | dog +1 (0-1) | 33 | 33% | 15% | 52% | 18% | 61% | 82% | 0% | 1-2 (15%), 3-1 (12%) |
| Medium+Goals | fav +1 (1-0) | 58 | 79% | 12% | 9% | 29% | 50% | 55% | 0% | 2-0 (14%), 2-1 (12%) |
| Medium+Normal | 0-0 | 489 | 47% | 35% | 18% | 62% | 15% | 45% | 15% | 1-1 (16%), 0-0 (15%) |
| Medium+Normal | dog +1 (0-1) | 74 | 32% | 22% | 46% | 31% | 43% | 82% | 0% | 1-2 (15%), 1-1 (15%) |
| Medium+Normal | fav +1 (1-0) | 159 | 75% | 18% | 6% | 42% | 32% | 54% | 0% | 2-0 (17%), 1-0 (13%) |
| Medium+Tight | 0-0 | 234 | 48% | 35% | 17% | 71% | 12% | 38% | 15% | 1-0 (21%), 1-1 (16%) |
| Medium+Tight | dog +1 (0-1) | 35 | 20% | 43% | 37% | 31% | 49% | 89% | 0% | 1-1 (20%), 2-2 (17%) |
| Medium+Tight | fav +1 (1-0) | 60 | 82% | 18% | 0% | 38% | 33% | 62% | 0% | 2-1 (20%), 2-0 (13%) |
| Barabar+Goals | 0-0 | 51 | 35% | 31% | 33% | 55% | 22% | 49% | 10% | 1-1 (14%), 0-1 (14%) |
| Barabar+Normal | 0-0 | 247 | 40% | 32% | 28% | 61% | 19% | 45% | 13% | 1-1 (14%), 0-0 (13%) |
| Barabar+Normal | dog +1 (0-1) | 59 | 24% | 22% | 54% | 32% | 39% | 75% | 0% | 1-1 (15%), 1-2 (14%) |
| Barabar+Normal | fav +1 (1-0) | 64 | 53% | 28% | 19% | 36% | 38% | 77% | 0% | 1-1 (17%), 2-1 (12%) |
| Barabar+Tight | 0-0 | 272 | 42% | 33% | 25% | 69% | 12% | 38% | 17% | 0-0 (17%), 1-0 (16%) |
| Barabar+Tight | dog +1 (0-1) | 54 | 17% | 24% | 59% | 35% | 28% | 70% | 0% | 1-2 (19%), 1-1 (15%) |
| Barabar+Tight | fav +1 (1-0) | 68 | 62% | 22% | 16% | 43% | 25% | 60% | 0% | 1-0 (15%), 1-1 (15%) |

### 24.3 Half-time par — category + score (n ≥ 30 wali rows)
| Category | Score | n | Fav jeete | Draw | Fav haare | Under 2.5 | 4+ goal | BTTS | FT 0-0 | Top 2 score (fav-dog) |
|---|---|---|---|---|---|---|---|---|---|---|
| Strong+Goals | 0-0 | 100 | 63% | 28% | 9% | 74% | 8% | 27% | 16% | 1-0 (26%), 0-0 (16%) |
| Strong+Goals | dog +1 (0-1) | 46 | 35% | 33% | 33% | 41% | 37% | 78% | 0% | 1-1 (24%), 2-1 (13%) |
| Strong+Goals | fav +1 (1-0) | 141 | 84% | 12% | 4% | 44% | 31% | 45% | 0% | 2-0 (20%), 1-0 (18%) |
| Strong+Goals | fav +1 (2-1+) | 33 | 94% | 3% | 3% | 0% | 79% | 100% | 0% | 2-1 (21%), 3-2 (21%) |
| Strong+Goals | fav +2 | 105 | 96% | 4% | 0% | 10% | 66% | 44% | 0% | 3-0 (19%), 4-0 (14%) |
| Strong+Goals | level 1-1 | 47 | 60% | 19% | 21% | 6% | 66% | 100% | 0% | 2-1 (19%), 3-1 (17%) |
| Strong+Normal | 0-0 | 73 | 59% | 29% | 12% | 84% | 0% | 22% | 16% | 1-0 (27%), 2-0 (21%) |
| Strong+Normal | fav +1 (1-0) | 67 | 82% | 16% | 1% | 61% | 21% | 39% | 0% | 2-0 (27%), 1-0 (22%) |
| Strong+Normal | fav +2 | 50 | 92% | 8% | 0% | 10% | 56% | 42% | 0% | 3-0 (20%), 2-1 (14%) |
| Medium+Goals | 0-0 | 86 | 48% | 36% | 16% | 81% | 6% | 23% | 24% | 0-0 (24%), 1-0 (19%) |
| Medium+Goals | dog +1 (0-1) | 34 | 29% | 18% | 53% | 32% | 29% | 74% | 0% | 2-1 (21%), 1-2 (18%) |
| Medium+Goals | fav +1 (1-0) | 62 | 81% | 13% | 6% | 48% | 29% | 45% | 0% | 2-0 (21%), 1-0 (21%) |
| Medium+Goals | fav +2 | 39 | 92% | 5% | 3% | 13% | 69% | 51% | 0% | 3-0 (13%), 4-0 (13%) |
| Medium+Goals | level 1-1 | 34 | 53% | 21% | 26% | 15% | 53% | 100% | 0% | 2-1 (18%), 3-1 (18%) |
| Medium+Normal | 0-0 | 230 | 37% | 50% | 13% | 86% | 3% | 27% | 33% | 0-0 (33%), 1-0 (20%) |
| Medium+Normal | dog +1 (0-1) | 97 | 19% | 35% | 46% | 52% | 20% | 73% | 0% | 1-1 (26%), 0-1 (16%) |
| Medium+Normal | fav +1 (1-0) | 208 | 75% | 17% | 8% | 57% | 18% | 41% | 0% | 1-0 (23%), 2-0 (21%) |
| Medium+Normal | fav +2 | 83 | 93% | 4% | 4% | 12% | 53% | 53% | 0% | 3-0 (20%), 2-1 (14%) |
| Medium+Normal | level 1-1 | 73 | 49% | 33% | 18% | 26% | 38% | 100% | 0% | 1-1 (26%), 2-1 (25%) |
| Medium+Tight | 0-0 | 127 | 43% | 40% | 17% | 88% | 2% | 19% | 27% | 0-0 (27%), 1-0 (27%) |
| Medium+Tight | dog +1 (0-1) | 48 | 17% | 38% | 46% | 50% | 25% | 75% | 0% | 1-1 (25%), 0-1 (12%) |
| Medium+Tight | fav +1 (1-0) | 86 | 77% | 20% | 3% | 62% | 14% | 43% | 0% | 1-0 (26%), 2-0 (19%) |
| Medium+Tight | level 1-1 | 35 | 43% | 51% | 6% | 29% | 43% | 100% | 0% | 1-1 (29%), 2-1 (23%) |
| Barabar+Normal | 0-0 | 118 | 41% | 36% | 23% | 81% | 6% | 25% | 27% | 0-0 (27%), 1-0 (18%) |
| Barabar+Normal | dog +1 (0-1) | 65 | 12% | 29% | 58% | 54% | 20% | 62% | 0% | 1-1 (25%), 0-1 (18%) |
| Barabar+Normal | fav +1 (1-0) | 77 | 61% | 26% | 13% | 57% | 17% | 57% | 0% | 1-1 (22%), 1-0 (18%) |
| Barabar+Normal | level 1-1 | 43 | 33% | 44% | 23% | 33% | 37% | 100% | 0% | 1-1 (33%), 1-2 (16%) |
| Barabar+Tight | 0-0 | 161 | 35% | 42% | 24% | 86% | 4% | 24% | 28% | 0-0 (28%), 1-0 (19%) |
| Barabar+Tight | dog +1 (0-1) | 62 | 13% | 21% | 66% | 48% | 16% | 56% | 0% | 0-1 (21%), 1-2 (15%) |
| Barabar+Tight | fav +1 (1-0) | 83 | 71% | 23% | 6% | 64% | 18% | 46% | 0% | 1-0 (28%), 2-0 (19%) |
| Barabar+Tight | fav +2 | 32 | 91% | 6% | 3% | 16% | 47% | 50% | 0% | 3-0 (31%), 2-0 (16%) |
| Barabar+Tight | level 1-1 | 53 | 28% | 38% | 34% | 23% | 38% | 100% | 0% | 1-2 (25%), 1-1 (23%) |

### 24.4 Kya badalta hai (misaalein)
- **Medium fav + Normal** match: pre-match Under 2.5 **52%** → 20' par 0-0 → **62%** → HT 0-0 → **86%** (FT 0-0 bhi 33%).
- **Strong fav + Goals:** pre-match fav jeete **73%** → 20' par fav 1-0 → **86%** → HT fav 2-0 → **96%**.
- **Dog 20' par 1-0 aage** (Strong fav + Goals): BTTS **94%**, 4+ goal **73%** — fav aksar wapas aata hai aur match khul jata hai.
- **HT 1-1** (koi bhi category): BTTS 100% (ho chuka), aur 4+ goal 37-66% — Goals wali category me 66%.
- **Barabar + Tight, HT par dog 1-0 aage:** fav sirf 13% jeetta, dog 66% — yahan dog ko back karna value ho sakta hai agar odds theek hon.

### 24.5 0-0 ke signals
**Base:** sirf **7.7%** matches 0-0 khatam hote hain (teeno leagues same, n=3,234). Pre-match 0-0 kabhi "zyada mumkin" nahi hota.

| Pre-match signal | n | FT 0-0 |
|---|---|---|
| O2.5 opening ≤ 1.70 | 883 | 4.8% |
| O2.5 1.71-2.05 | 1,420 | 8.4% |
| O2.5 2.06-2.30 | 654 | 9.3% |
| **O2.5 opening ≥ 2.30** | 148 | **14.9%** |
| Dono teams pichle 6 me ≤1.0 goal/match | 400 | 10.2% |
| **Tight (O2.5 > 2.05) + dono teams ≤1.0 goal/match** | 184 | **13.6%** |
| Serie A + O2.5 ≥ 2.30 | 220 | 11.4% |
| Pichle matches me 0-0 ki aadat (2+ 0-0) | 699 | 7.7% (koi asar nahi) |

| Live: abhi tak 0-0 | n | FT 0-0 | Tight match me |
|---|---|---|---|
| 20' | 1,989 | 12.5% | 15.9% |
| 30' | 1,524 | 16.3% | 19.8% |
| **HT** | 968 | **25.7%** | 27.8% |
| 60' | 636 | 39.2% | 39.9% |
| 70' | 484 | 51.4% | 50.6% |
| 75' | 418 | 59.6% | 59.3% |
| **80'** | 366 | **68.0%** | 65.9% |

**0-0 ke strongest signals (sab mila kar):** O2.5 opening 2.30+ · Tight category · dono teams ka attack kamzor (≤1 goal/match) · HT 0-0 · live me **dono teams ke shots on target bohat kam** (Section 21.3: total SOT 0-4 → Over 2.5 sirf ~8%). Phir bhi **0-0 pehli baar 70' ke baad hi 50% se upar** jata hai. Pre-match "Correct score 0-0" ka fair odds ~7-13 hai — is se kam par kabhi mat lo.

### 24.6 Live use ka tareeqa (har live screenshot par)
1. Pre-match odds se category (24.1) — screenshot me na ho to user se opening odds poochho.
2. Minute 15-25 → 24.2; 40-50 → 24.3; 60'+ → Section 22.3 jackpot table + Section 19.
3. Live stats (SOT, xG, red card) se row ko upar/neeche karo — red card ho to row reset (Section 14.1).
4. Top 2 score row ke "Top 2" column se do (user ki shart).
5. Bet sirf jab live odds > (100 / row ka %) × 1.05. Warna "No bet".
