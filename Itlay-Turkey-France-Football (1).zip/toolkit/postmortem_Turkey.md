## 15. Post-mortem — 16 Oct 2026: Çorum FK 2-1 Rizespor (HT 1-1)

- **Pre-match odds:** 2.00 / 3.70 / 3.40, O2.5 1.60, Under 3 (Asian) 1.86, BTTS 1.53. **Neighbour search (Süper Lig ±4, n=193):** H 48%, D 36%, A 17%; ≤2 goal 54%, exactly 3 23%, 4+ 23%.
- **Pre-match post:** Under 3 Asian @1.86 → ↩️ **refund** (exactly 3 goal).
- **Live (60', 1-1):** grid (Süper Lig 1-1 at 60', n=135): aur goal nahi 36%, sirf 1 aur 33%, 2+ 32%; draw 44%, Çorum 34%, Rize 21%. Live "ek bet" **Under 3.5 @1.56 → ✅ jeeti**. Live post Draw @2.40 → ❌. Top-2 score 1-1 (36%) / 2-1 (18%) → **2-1 ✅**.
- **Kya hua:** Çorum ne 80' par winner kiya (ghar ki fav team, level score — sab se aam rasta).
- **Kya galat tha / kya sahi:** "Aur goal aayega" ~64% hamare data me tha aur sahi nikla; Draw 44% wali pick haari (56% baar aisa hota hai). User ne kaha "Over 2.5 pakka kehna chahiye tha" — data 64-66% deta hai, yani 3 me se 1 baar 1-1 hi rehta. Over 2.5 @1.37 ki value −11% thi.
- **Lessons:** (1) Live level score + home fav → **draw ke bajaye "Under (current+1.5)" ya "home double chance"** zyada mehfooz; Draw 1.80+ par sirf chhota stake. (2) Over 2.5 live tabhi jab odds ≥1.60. (3) "Pakka" kabhi nahi — lekin "zyada mumkin side" saaf batao (yahan: aur goal 64%).

### Pichla (12 Oct): Eyüpspor 0-4 Göztepe
- Pick Eyüpspor +0.5 ❌ — edge zero tha, 9' red card, Eyüpspor ki defence collapse. **Lesson:** edge zero ho to no bet; 10 men team par "+0.5" mat lagao.
