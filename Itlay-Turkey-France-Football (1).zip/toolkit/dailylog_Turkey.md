## 16. Daily match log & lessons (2026-27)

**Note:** naye finished matches ka record. Saare section numbers (1-14) har update par poore data se dobara bante hain.

| Date | Match | HT | Goals | 81+ goals | Comeback (team, result, deficit, minute) | Red card |
|---|---|---|---|---|---|---|
| 10-09 | Galatasaray 3-1 Kasimpasa | 1-0 | Galatasaray 45', Kasimpasa 68', Galatasaray 90', Galatasaray 90' | Galatasaray 90', Galatasaray 90' | - | Galatasaray |
| 10-10 | Genclerbirligi 2-2 Amed Sportif Faaliyetler | 0-1 | Amed 25', Genclerbirligi 54', Amed 68', Genclerbirligi 90' | Genclerbirligi 90' | Genclerbirligi (Draw, -1, 90') | - |
| 10-10 | Alanyaspor 0-0 Erzurumspor FK | 0-0 | - | - | - | - |
| 10-10 | Samsunspor 0-3 Trabzonspor | 0-3 | Trabzonspor 28', Trabzonspor 38', Trabzonspor 40' | - | - | Trabzonspor |
| 10-10 | Rizespor 0-3 Fenerbahce | 0-1 | Fenerbahce 12', Fenerbahce 83', Fenerbahce 87' | Fenerbahce 83', Fenerbahce 87' | - | - |
| 10-11 | Konyaspor 0-0 Buyuksehyr | 0-0 | - | - | - | - |
| 10-11 | Gaziantep 0-3 Çorum FK | 0-1 | Çorum 37', Çorum 60', Çorum 83' | Çorum FK 83' | - | - |
| 10-11 | Besiktas 2-1 Kocaelispor | 2-1 | Besiktas 18', Kocaelispor 27', Besiktas 31' | - | - | - |

**Lessons (09-11 Oct, 8 matches):**
1. **Late goals:** 4/8 matches me 81'+ goal (50%; base 43.3%): Galatasaray (90', 90+6), Gençlerbirliği (90+3 equalizer), Fenerbahçe (83', 87'), Çorum (83'). Section 10 team table confirm: Galatasaray late scorer #1 (40%), Fenerbahçe (35%), Rizespor late conceder (30%). Rize ke dono late goals Fenerbahçe ke substitutes ne kiye (sources) — substitution minute data me nahi, is liye rule nahi bana sakte.
2. **Gençlerbirliği 2-2 Amedspor:** Amedspor 2 baar aage hua (25' pen, 68'), Gençlerbirliği ne 54' aur 90+3 me jawab diya (HT 0-1 se draw). 2-1 ki lead 22 min baad bhi nahi bachi — Section 7 (70' par 1-goal lead: draw ~19%) se milta hai.
3. **Samsunspor 0-3 Trabzonspor:** 12 min me 3 goal (28', 38', 40'), phir Trabzonspor ko 43' me red — 2nd half 10 men se 3-0 bachaya. HT 2+ lead + opponent ka pressure = phir bhi hold (Section 7).
4. **0-0 x2 (Alanyaspor-Erzurumspor, Konyaspor-Başakşehir):** dono me ghar ki team ke paas possession 54-55% tha lekin gol ke khatre kam (Konyaspor 3 on target, Başakşehir 0; Alanya 4 vs Erzurum 5). HT 0-0 se FT 0-0 ka base ~27.7% hai.
5. **Away wins:** 3 away 3-0 wins (Trabzonspor, Fenerbahçe, Çorum) aur 2 ghar ki jeet (Galatasaray, Beşiktaş); ghar ki jeet 2/8 = 25% (base ~46%). 2 din ka chhota sample hai — extrapolate na karen.
6. **Galatasaray 3-1 (10 men):** red ~63-65', phir bhi 68' ke barabar goal ke baad 90' aur 90+6 me 2 goal. Section 14.1 (home red par home win 31%) ka ek apwad, rule nahi.
7. **Beşiktaş 2-1:** teeno goal 31' tak (18', 27', 31'), 2nd half me koi goal nahi. Data note: Turkey ke naye matches me shots/cards aksar available nahi (sirf score, HT, goal minutes, kuch red cards).

### 12 Oct 2026 (naya)
| Date | Match | HT | Goals | 81+ goals | Comeback | Red card |
|---|---|---|---|---|---|---|
| 10-12 | Eyupspor 0-4 Göztepe | 0-1 | Göztepe 11' (pen), 54', 59', 75' (pen) | - | - | Eyupspor (9') |

### 16 Oct 2026 (naya) — Çorum FK 2-1 Rizespor
| Date | Match | HT | Goals | 81+ goals | Comeback | Red card |
|---|---|---|---|---|---|---|
| 10-16 | Çorum FK 2-1 Rizespor | 1-1 | Rizespor 32' (Laci), Çorum 38' (Under), Çorum 80' | - | Çorum FK (Win, -1, 80') | - |

**Match details (Flashscore summary, user ke screenshots):** Yellow: Ariss (Rize) 12', Özdemir (Çorum) 27'. Subs: Çorum 25' Şengül ↔ Borza (injury), 46' Ramadani ↔ Diomande; Rize 61' Bulut ↔ Mihaila. Pre-match odds 2.00 / 3.70 / 3.40, O2.5 1.60 / U2.5 2.20, BTTS 1.53. Live (~60', 1-1, exchange): Çorum 2.76, Draw 2.40, Rize 3.95, O2.5 1.37, U2.5 3.55, O3.5 2.74, U3.5 1.54. Shots/possession/xG: link se load nahi hue — user screenshot de to `--update` se daalo.

**User ka sawal: "80' me goal kyun aaya? Over 2.5 pakka kehna chahiye tha."**
| Sawal | Purane matches | Faisla |
|---|---|---|
| 60' par 1-1 → aur goal? | Süper Lig 64% (n=135); home fav wale 66% (n=85); teeno leagues 67% (n=401) | **Aam natija** (60%+). Over 2.5 zyada mumkin tha — lekin "pakka" nahi: 1/3 matches 1-1 par khatam hote hain |
| Naya goal kis ka? | Home fav ho to 64% baar pehla naya goal home team ka | Aam — Çorum ghar par aur favourite tha |
| Goal kab? | Pehla naya goal 61-70' 32%, 71-80' 16%, 81'+ 16% | 80' wala goal normal range me |
| Over 2.5 @1.37 value? | Asal ~64-66% → fair 1.52 | Over sahi side tha, lekin 1.37 par value nahi thi (−11%) |

**Kyun hua (match se):** Çorum ghar par favourite tha aur 7 me se 3 matches me 4+ goal wali team hai; 46' ka sub (Ramadani) attack ke liye. Rizespor ne 61' par sub kiya aur pichle 7 me se 4 match haara tha. 1-1 ke baad ghar ki fav team aksar dabaav banati hai.

**Sabaq:**
1. **60' par 1-1 (Süper Lig) = aur goal ~64-66%.** Yeh "zyada mumkin" hai, "pakka" nahi. Over 2.5 sirf tab lo jab odds ≥1.60 hon (fair ~1.52 + 5% value).
2. **Home fav level ho to agla goal ~64% home ka** (agar goal aaye). Yani "Next goal: home" ka asal chance ≈ 66% × 64% ≈ 42% → fair odds ~2.38. Live 2.12 par value nahi thi; 2.50+ par hoti.
3. **Hamari live "ek bet" Under 3.5 @1.56 ✅ jeeti** (3 goal). Draw @2.40 ❌. Pre-match Under 3 Asian @1.86 ↩️ refund. Top-2 score 1-1 / 2-1 → 2-1 aaya ✅.

### 17-18 Oct 2026 (Süper Lig, Round 8) — 8 matches
(Dates: Kocaelispor-Goztep 18 Oct 18:00 aur Erzurum-Eyupspor 17 Oct confirmed; baaki 6 ki tareekh 18 Oct andaaza hai, Flashscore dump me nahi thi. Amedspor-Konyaspor ke stats/odds dump me nahi the.)
| Match | FT (HT) | Goals | xG | SOT | Odds 1X2 |
|---|---|---|---|---|---|
| Kasimpasa 4-1 Samsunspor | 4-1 (2-1) | Kas 26', 31', 64', 78'; Sam 45' | 2.41-1.07 | 9-4 | 2.46/3.42/2.91 |
| Kocaelispor 1-2 Goztep | 1-2 (0-1) | Goztep 24' (og), 77'; Kocaeli 82' (pen) | 1.61-0.83 | 4-3 | 2.97/3.32/2.48 |
| Basaksehir 2-1 Gaziantep | 2-1 (1-0) | Bas 8'; Gaz 66'; Bas 81' | 1.95-1.42 | 6-4 | 1.75/4.04/4.47 |
| Erzurumspor 2-0 Eyupspor | 2-0 (1-0) | Erz 19', 47' | 1.29-0.43 | 3-4 | 1.50/4.17/7.29 |
| Amedspor 1-0 Konyaspor | 1-0 (0-0) | Amed 86' | - | - | - |
| Genclerbirligi 0-1 Galatasaray | 0-1 (0-0) | Gala 88' (og) | 1.74-1.92 | 6-4 | 8.16/5.53/1.35 |
| Fenerbahce 3-0 Alanyaspor | 3-0 (1-0) | Fener 40', 71', 87' | 3.84-0.96 | 7-5 | 1.29/5.98/10.20 |
| Trabzonspor 2-0 Besiktas | 2-0 (1-0) | Trab 21', 71' | 2.41-1.32 | 8-7 | 2.54/3.86/2.58 |

**1. Kasimpasa 4-1 Samsunspor — 5 goal kyun?** xG 2.41 vs 1.07, 23 shots (9 SOT) vs 12 (4 SOT), big chances 4-3. Samsunspor ka ek goal 45' par aaya (HT 2-1). HT 2-1 par 5+ goals 47% (n=111; Turkey akela 43%, n=42), aur ghar ki jeet 73%. Yaani 5 goal "aam" band me tha. Kasimpasa ne 64' aur 78' par 2 goal 2nd half me kiye.
**2. Kocaelispor 1-2 Goztep — fav (Goztep 2.48) jeeta, ghar ne 62% ball rakhi.** Goztep ka pehla goal own goal tha (24'). Kocaeli: 13 shots, xG 1.61 vs 0.83, magar 3 SOT ke saath 4 SOT. Away fav 2.3-2.7: jeet 40%, draw 29%, haar 30% (n=275). HT par aage ho to jeet 60% (n=62). Possession/shots ka bhaari hona jeet nahi banata — Goztep ke 8 shots me se 3 SOT aur 2 goal.
**3. Basaksehir 2-1 Gaziantep — Over 2.5 kyun?** xG total 3.37 (1.95-1.42), shots 14-12. Home fav 1.65-1.85 par Over 2.5 sirf 46%; HT 1-0 par 38% aur BTTS Yes 36% (n=86). Over isliye hit hua ke Gaziantep ne 66' par barabar kiya aur 81' par Basaksehir ne winner mara. Rare nahi, par fav ki odds-based Over 38% hi tha.
**4. Erzurumspor 2-0 Eyupspor — Under 2.5 aur BTTS No kyun?** Home fav 1.4-1.6 HT 1-0 par BTTS No 58%, U2.5 57%, jeet 80% (n=89). Eyupspor ke 10 shots the magar xG sirf 0.43, xGOT 0.24 (4 SOT) — Erzurum ne sirf 7 shots (3 SOT, xG 1.29) me 19' aur 47' par 2 goal kiye, 37' ka 2nd goal foul se cancel hua. Eyupspor ke shots door se / blocked the (xG/shot ~0.04).
**5. Amedspor 1-0 Konyaspor — sirf 1 goal aur woh 86' me kyun?** (stats nahi mile.) HT 0-0 par pehla goal 80' ke baad aane ka chance sirf 13% (n=933); 0-0 at 85' par match 0-0 hi rehta 77%. Yaani 86' ka goal rare tha (~23%), aur HT 0-0 se FT sirf 1 goal 31%. Dono teams ne 63'-80' me 3-3 subs kiye.
**6. Genclerbirligi 0-1 Galatasaray — 1.35 par 88' ka own goal, 0-0 kyun nahi?** Away fav <1.5, HT 0-0: jeet 79%, draw 18%, 0-0 sirf 11% (n=28); in jeeton me winner 80'+ me 59% (n=22). Match me xG 1.74-1.92 (barabar!), shots 19-18, SOT 6-4 — Genc ne bhi chances banaye; Gala ka GK 6 save, Gala ka goal bhi own goal (88'). 0-0 at 85' ke baad goal aane ka chance 23%. **1.35 ka odds is match ki asli barabari ko nahi dikhata**: xG ne yeh match barabar dikhaya.
**7. Fenerbahce 3-0 Alanyaspor — BTTS No, 87' goal.** Home fav <1.35: jeet 76%, BTTS No sirf 41%, U2.5 32%, 3+ goal margin 27% (n=230); 85'+ goal 40%. xG 3.84-0.96, 8 big chances (6 miss), Greenwood penalty miss 17'. BTTS No isliye hua ke Alanya ka xGOT sirf 0.68.
**8. Trabzonspor 2-0 Besiktas — BTTS No aur Under 2.5 kyun?** Barabar odds (2.54 vs 2.58) + HT 1-0: BTTS No sirf 31%, U2.5 46%, home jeet 54% (n=35) — yaani BTTS No yahan **surprise** tha. Besiktas ke 19 shots, 7 SOT, xG 1.32 magar 0 goal: Trabzon GK ne 1.35 goal bachaye (xGOT 1.35 faced, 0 conceded). Trabzon ke 6 big chances vs 1.

**Naye rules (data, Turkey + sab leagues):**
1. **HT 2-1: 5+ goals 47%** (Turkey 43%) — Over 3.5 par value tab hi jab odds 2.20+.
2. **Away fav 2.3-2.7 sirf 40% jeetta; HT par aage ho to 60%.** Possession ya shots dominance (Kocaeli 62%) jeet nahi banata.
3. **Home fav 1.4-1.6 HT 1-0 → BTTS No 58%, U2.5 57%, jeet 80%.** Fener (<1.35) par BTTS No sirf 41% — heavy fav ke saath BTTS No par jaldi mat karo.
4. **HT 0-0: pehla goal 80'+ sirf 13%; 0-0 at 85' me goal 23%** (Amedspor 86', Gala 88' dono rare-ish). "Late goal" par tabhi bet jab odds 4.00+.
5. **Strong away fav HT 0-0: jeet 79%, par 59% jeeton me winner 80'+.** 1.35 par pre-match "Galatasaray jeet" aksar late goal par nirbhar.
6. **Odds vs xG:** Gala (1.35, xG 1.92 vs 1.74), Besiktas (19 shots, GK ne roka) — result ke baad rule mat banao; xG aur GK performance (goals prevented) dono dekho.
