# POST-MORTEM + NAYI PREDICTIONS — 31 Oct 2026

## HISSA 1 — POST-MORTEM (5 khatam shuda match)

### Khulasa: 3 match me Over jeeti, 1 me Under. Main ne 0 Over di.

| Match | Natija | Total | O2.5 odds | teamO | Sec64 kehta tha | Over 2.5 |
|---|---|---|---|---|---|---|
| Le Havre v PSG | 1-5 | 6 | 1.37 | 50.0% | NAHI | jeeti |
| Nice v Rennes | 5-2 | 7 | 1.53 | 62.5% | **HAAN** | jeeti |
| Konyaspor v Galatasaray | 0-4 | 4 | 1.60 | 47.5% | NAHI | jeeti |
| Lille v Lens | 1-0 | 1 | 1.81 | — | lagu nahi | haari |

---

### 1. Konyaspor 0-4 Galatasaray — "Over 2.5 shuru me kyun nahi batayi"

**Itna score kyun hua:** Galatasaray xG 2.80 vs Konyaspor 1.38 (kul 4.18). Gala ke 6 big chances, 16 shots, 8 on target, xGOT 3.52. Konyaspor ka goalkeeper −0.48 goals prevented, yani average se bura. Osimhen 12', Akgun 28', Batrakov 49', Leao 55' penalty.

**Match se pehle data kya kehta tha:** O2.5 odds 1.60 (market bullish), **lekin** Konyaspor ghar par sirf 35% over, Galatasaray bahar 60% — average 47.5%. Goal andaza 2.48. GOAL LEAN = NEUTRAL.

**Ab kya kehta hai — yahi sab se ahem baat:** Main ne 3,131 match par yeh bucket test kiya. Jab market O2.5 ≤1.60 ho **magar** teamO <60% ho:

> **n=240, over sirf 59.6%, ROI −12.1%**

Yani aisi 240 betein lagao to 12% paisa doobta hai. Yeh bet policy ke hisaab se chhorni hi thi. Aaj haar gaye — qaida phir bhi theek hai.

Muqable me jab teamO ≥60% ho: **n=221, over 74.7%, ROI +8.2%.** Filter ke baghair sab ≤1.60 par lagao: ROI −3.8%. **Filter hi munafa banata hai.**

---

### 2. Nice 5-2 Rennes — **yeh meri asli galti thi**

**Itna score kyun hua:** xG 3.44 vs 2.61 (kul 6.05!). Nice ke 7 big chances, 5 convert. Rennes ka GK −2.07 goals prevented aur 2 error leading to goal. Wahi ke 3 goal (2 penalty).

**Match se pehle data kya kehta tha:** goal andaza **3.22**, teamO **62.5%** (Rennes bahar 80% over!), O2.5 1.53. Gate ka apna **GOAL LEAN = OVER** tha, aur Section 64 bhi HAAN kehta.

**To diya kyun nahi:** kyunke Over 2.5 @1.53 aap ke **1.80 floor se neeche** tha, is liye wo gate ki list me aaya hi nahi. System ne sahi dekha, qaide ne chhupa diya.

Main ne Rennes win @2.50 di — wo haari (Rennes GK ne match phenk diya).

**Ab theek ho gaya:** 63-3b (floor 1.35 high-confidence par) + Section 64 ke baad yeh pick ab milegi.

---

### 3. Le Havre 1-5 PSG

**Itna score kyun hua:** PSG xG 3.97 vs 2.01. Hakimi ne hat-trick ki (28', 55', 69'), 3 assist bhi. PSG 71% possession, 10 shots on target.

**Pehle bhi aur ab bhi: NO BET.** teamO sirf 50% (Le Havre ghar 40%, PSG bahar 60%) — wohi −12.1% wala bucket. Yeh bhi policy ke tehat chhorni thi.

---

### 4. Lille 1-0 Lens — "low scoring kyun, aur 86' goal kyun"

**Itna kam score kyun:** Lille xG 1.63 vs Lens **0.19** — Lens ne poore match me 5 shot mare. Lens ka GK ne **6 save** kiye, +1.14 goals prevented. Lille ne **2 baar woodwork** hit ki aur 4 big chances miss ki.

Aise matches ka historical record (ek team xG ≥1.5, doosri ≤0.5, n=288): average 2.67 goal, **BTTS No 67%**, Under 2.5 51%. To BTTS No hona bilkul normal tha.

**0-0 par khatam kyun nahi hua — 86' goal kyun:** yeh sab se kaam ki baat hai.

| Kab tak 0-0 | 0-0 par khatam hua | Goal aa gaya |
|---|---|---|
| 70' | 51.2% | **48.8%** |
| 75' | 59.3% | **40.7%** |
| 80' | 67.9% | **32.1%** |
| 85' | 77.1% | **22.9%** |

(n=327 se 492)

Yani **80' tak 0-0 ho to bhi har 3 me se 1 match me goal aa jata hai.** Giroud ka 86' goal koi ajooba nahi — normal hai. Isi liye late me 0-0/Under par bet khatarnak hai.

**Aur ek ahem baat (apni galti):** kal main ne 63-2b rule banaya tha — DNB ko DC-type karna — jis se **Lens DNB @1.85 LEAN ban jati**. Wo **haar jati** (Lille 1-0). Purana ULTA block sahi tha. Is rule ko 20 pick tak watch par rakh raha hoon.

---

### 5. Fiorentina 2-2 Atalanta — BTTS No kyun haari

Fiorentina xG 1.51, Atalanta 1.01 — dono ne score kiya. Match se pehle BTTS Yes 1.50 tha, yani **62-A goal-bullish** — rule saaf kehta tha BTTS No nahi lagani. Maine apna hi rule tora tha. Yeh Section 62 me save hai aur Section 63-7 me "kabhi nahi" ki list me hai.

---

## HISSA 2 — BAQI MATCHES KI PREDICTION (naye rules se)

**2 sab se behtar: Section 64 ke Super Lig wale.** Section 64 ka record: Super Lig me n=106, hit 80.2%, ROI +14.5%.

### ⭐ SAB SE BEHTAR 3

**1. Fenerbahce v Goztepe — Over 2.5 @ 1.44** (SAT 21:00)
Section 64 qualify: O2.5 1.44 ≤1.60, teamO 60% (Fener ghar 70% over), Super Lig. Fenerbahce ghar par 13-6-1 aur 2.65 goal per match. Goal andaza 3.20, GOAL LEAN = OVER.
*50 words:* Fenerbahce have won thirteen of twenty at home scoring 2.65 a game, and Goztepe concede regularly on the road. Seventy percent of Fenerbahce home games pass 2.5 goals. The market agrees at 1.44. This pattern wins 80% in Super Lig historically, though the odds are short.
*Scores: 2-0 (10%), 2-1 (10%). Stake 0.5%.*

**2. Trabzonspor v Gaziantep — Over 2.5 @ 1.43** (SUN 18:00)
Section 64 qualify: teamO 60%, Super Lig. Saath me gate ne **Trabzonspor win @1.37** bhi LEAN-H di (77% median chance, 5-pattern saath, venue gap +0.95). Dono ek hi match me.
*50 words:* Trabzonspor are twelve wins from twenty at home with two goals a game, while Gaziantep ship 1.7 away and see 65% of their trips go over. H2H averages 3.33. The market prices goals at 1.43 and the venue records agree, which is the combination that historically wins eighty percent.
*Scores: 2-0 (10%), 2-1 (10%). Stake 0.5%.*

**3. Frosinone v Torino — Frosinone or Draw (DC 1X) @ 1.40** (SUN 19:00)
**Yeh is weekend ki sab se saaf bet hai.** Conservative chance 77.3%, gate ka min odds 1.34, mil raha 1.40 — yani **conservative test bhi pass**, jo aur kisi pick ne nahi kiya. Cells 3/0, 5-pattern saath, edge +8% (conservative) / +11% (median).
*50 words:* Frosinone are unbeaten enough at home to make the double chance comfortable, and Torino travel 4-6-10 scoring only one a game. The venue gap favours the hosts by 0.60. This is the one market all weekend that clears the conservative threshold, not just the optimistic one.
*Scores: 1-1 (10%), 2-1 (9%). Stake 0.5%.*
*(Isi match me Over 2.5 @1.43 bhi Section 64 qualify karta hai, lekin Serie A me sirf n=15 history hai — faisla nahi ho sakta.)*

---

### Baqi matches

**SAT 31 Oct**

**Erzurum v Corum (15:30) — NO BET (data kam)**
Dono promoted, venue sample sirf 4-5 match, 57-E ki 10-match hadd se neeche. Gate ne Erzurum win @2.60 dikhayi par chance band 25-50% hai, bharosa nahi.
*50 words:* Both clubs came up this season, so their venue records run to four and five games, below the ten-match minimum the rules demand. Corum have scored 2.4 away in that tiny sample and the goal estimate is 3.30, but there is not enough history to price anything.
*Scores: 1-1 (13%), 1-0 (10%).*

**Kocaelispor v Rizespor (18:00) — NO BET**
Gate ne Kocaelispor DNB @1.83 LEAN di, lekin chance band 39-72% bohot chaura hai, aur DNB wala 63-2b rule abhi kal Lille-Lens me haar chuka hai. Is liye skip.
*50 words:* Kocaelispor concede only 0.7 at home and Rizespor draw often away, which makes the draw-void market tempting. But the confidence band runs from 39 to 72 percent, and the rule change that unlocked this market lost its first test last night. Not worth backing yet.
*Scores: 1-1 (13%), 1-0 (10%).*

**Bologna v Monza (19:00) — NO BET**
Bologna ghar par 3-6-11, Monza bahar 1-3-16 aur 2.4 goal khaati hai. Closest Monza or Draw @2.15 lekin 5-pattern ulta.
*50 words:* Bologna have a poor home record but Monza are far worse away, losing sixteen of twenty and conceding 2.4 a game. H2H averages just 1.75 goals. The nearest market runs against the five-pattern read, so rising odds would still not make it a bet.
*Scores: 1-1 (11%), 1-0 (11%).*

**Udinese v Roma (22:00) — NO BET**
Udinese ghar par 11 haar, 0.75 goal. Roma 1.53 par floor se neeche. Goal andaza sirf 2.30.
*50 words:* Udinese have lost eleven of twenty at home and score less than a goal a game, while Roma travel well but are priced at 1.53, under the floor. The goal estimate of 2.30 is low. The closest market reads against the pattern and needs 3.22.
*Scores: 1-2 (10%), 0-2 (10%).*

**SUN 1 Nov**

**Milan v Inter (00:45) — LEAN 0.5%: Inter win @ 2.00**
Inter bahar 14-4-2, 2.05 goal kiye 0.9 khaaye. Venue gap Inter ki taraf, 5-pattern saath. Cells 3/3.
*50 words:* Inter's away record is the standout number of the round: fourteen wins from twenty with two goals a game. Milan are solid at home but not dominant. The venue gap favours the visitors, so the pattern aligns, though three cells still fail and the price sits under the threshold.
*Scores: 1-1 (11%), 1-2 (9%).*

**Troyes v Le Mans (00:45) — NO BET (data kam)**
Dono promoted, 4-4 venue match. 57-E block.
*50 words:* Both sides are newly promoted with only four venue games each, below the minimum the rules require. What little exists is alarming, with Troyes conceding 2.75 at home, giving a goal estimate of 3.38, but four matches cannot price a market safely.
*Scores: 1-1 (12%), 1-0 (9%).*

**Amedspor v Eyupspor (15:30) — NO BET (data kam)**
Amedspor ghar par 5-0-0 aur 2.8 goal, par sirf 5 match — 57-E.
*50 words:* Amedspor have won all five home games scoring 2.8 a side, and Eyupspor have lost twelve of twenty away. The numbers look one-sided, but five matches is under the ten-game floor, so the gate will not price it. The closest market also reads against the pattern.
*Scores: 2-0 (13%), 1-0 (11%).*

**Como v Venezia (16:30) — NO BET**
Como ghar 11-6-3, Venezia bahar 0-8-12. 1.30 par kuch nahi bachta.
*50 words:* Como have lost three of twenty at home conceding 0.75, and Venezia have not won away all season at 0-8-12. The market reflects every bit of it at 1.30. Goal pricing of 1.41 blocks the under family, and nothing above the floor clears the gate.
*Scores: 2-0 (10%), 2-1 (9%).*

**Istanbul BB v Samsunspor (18:00) — LEAN 0.5%: Istanbul BB win @ 1.80**
Ghar par 11-5-4, 2.15 goal. Samsunspor bahar 6-5-9. Venue gap +0.75, 5-pattern saath, chance 54% — weekend ki sab se oonchi conservative chance.
*50 words:* Istanbul have won eleven of twenty at home scoring 2.15, while Samsunspor travel poorly and concede 1.7. The venue gap of 0.75 makes the pattern align, and 54 percent is the highest conservative reading of the weekend. No cells pass, though, and the price undercuts the minimum.
*Scores: 1-1 (11%), 2-1 (10%).*

**Lazio v Cagliari (19:00) — LEAN 0.5%: BTTS Yes @ 2.00 (value, kam hit-rate)**
Lazio ghar 1.4 goal karti par 1.25 khaati bhi hai. Cagliari bahar 65% over. Conservative chance sirf 42%.
*50 words:* Lazio score at home but also concede 1.25, and Cagliari have found the net in most away trips while shipping 1.6. Six cells pass on the median read. The conservative figure is only 42 percent, so this loses more often than it wins even when priced fairly.
*Scores: 2-0 (12%), 1-0 (12%).*

**Strasbourg v Auxerre (19:00) — NO BET (trigger qareeb)**
5-pattern saath (+0.95), chance 54%, par odds 1.80 aur min 1.88. Agar 1.88 par drift ho to LEAN.
*50 words:* Strasbourg score 1.7 at home and Auxerre have lost eleven of twenty away conceding 1.85, so the pattern aligns strongly. But no cells pass and the price sits below the minimum. If the home win drifts out to 1.88 this becomes a playable lean.
*Scores: 1-1 (11%), 2-1 (10%).*

**Kasimpasa v Besiktas (21:00) — NO BET**
Kasimpasa ghar 9 draw, Besiktas 1.58 floor se neeche. Goal andaza 2.55.
*50 words:* Kasimpasa draw nine of twenty at home and Besiktas travel 9-5-6, but at 1.58 the favourite is under the floor. The H2H average of three hints at goals, yet the estimate is only 2.55 and every over line fails on edge.
*Scores: 1-1 (10%), 0-1 (10%).*

**Lyon v Angers (21:15) — NO BET**
Lyon ghar 14-2-4, Angers bahar 11 haar. 1.40 fair hai.
*50 words:* Lyon have won fourteen of twenty at home and Angers have lost eleven away while scoring 0.75, so 1.40 is fair rather than generous. Over pricing at 1.56 blocks the under family, and the nearest qualifying market is the draw at sixteen percent.
*Scores: 2-0 (11%), 2-1 (10%).*

**Paris FC v Monaco (21:15) — LEAN 0.5%: Paris FC win @ 2.30 (value, kam hit-rate)**
Goal andaza 3.17, dono 60%+ over. Conservative chance sirf 40%.
*50 words:* Paris FC score 1.7 at home but leak 1.45, and Monaco's away record is middling. The goal estimate of 3.17 and both sides above sixty percent for overs point to an open game. Four cells pass and four fail, and forty percent conservative means frequent losses.
*Scores: 1-1 (12%), 1-0 (9%).*

**Lecce v Genoa (22:00) — NO BET**
Dono kamzor attack, goal andaza 2.17, GOAL LEAN = UNDER. Closest Over 2.25 ulta hai. N2 draw @3.00 optional.
*50 words:* Lecce score 0.7 at home and Genoa 0.9 away, with the head-to-head averaging 1.33 goals. The estimate of 2.17 actually leans under, which puts the closest market against the pattern despite four cells passing. The draw at 3.00 triggers the separate N2 alert only.
*Scores: 1-1 (13%), 0-1 (13%).*

**Marseille v Toulouse (2 Nov 00:45) — NO BET, par Section 64 qualify**
O2.5 1.55, teamO 70% (Marseille ghar 75% over) — Section 64 HAAN. **Lekin Ligue 1 me is rule ka ROI sirf +0.9%** (n=97, season-wise −15.7%/+15.9%/−13.9%). Is liye sirf watch, bet nahi.
*50 words:* Marseille score 2.35 at home with 75% of games going over, and Toulouse are middling away. The goal pattern qualifies on paper. But in Ligue 1 this rule has returned under one percent across 97 matches with wild season swings, so it is not reliable here.
*Scores: 1-1 (10%), 2-1 (10%).*

**Juventus v Napoli (2 Nov 00:45) — LEAN 0.5%: Juventus win @ 2.30 (value, kam hit-rate)**
Juve ghar 10-8-2 par 8 draw, isi liye chance sirf 40%.
*50 words:* Juventus have lost only two of twenty at home and concede 0.7, but they draw eight, which caps the win chance at forty percent. Napoli travel 10-4-6 and the goal estimate of 2.40 is low for a fixture of this size. The price sits well under minimum.
*Scores: 1-1 (13%), 1-0 (11%).*

---

**Yaad:** team news khud dekh lena (gate injuries nahi dekhta). Koi bet pakki nahi. Section 64 ka Ligue 1/Serie A hissa abhi kamzor hai — sirf Super Lig par bharosa.

✅ 3x recheck: data · rules · maths
