## 16. Daily match log & lessons (2026-27)

**Note:** naye finished matches ka record. Saare section numbers (1-14) har update par poore data se dobara bante hain.

| Date | Match | HT | Goals | 81+ goals | Comeback (team, result, deficit, minute) | Red card |
|---|---|---|---|---|---|---|
| 10-10 | Genoa 2-1 Fiorentina | 2-0 | Genoa 7', Genoa 15', Fiorentina 73' | - | - | - |
| 10-10 | Inter 3-0 Parma | 3-0 | Inter 13', Inter 18' (pen), Inter 31' | - | - | - |
| 10-10 | Napoli 3-0 Frosinone | 2-0 | Napoli 29', Napoli 32', Napoli 90' | Napoli 90' | - | - |
| 10-11 | Como 0-0 Roma | 0-0 | - | - | - | Roma |
| 10-11 | Lazio 3-1 Monza | 2-0 | Lazio 3', Lazio 23', Monza 46', Lazio 88' | Lazio 88' | - | Monza |
| 10-11 | Lecce 1-2 Bologna | 0-1 | Bologna 17', Lecce 64', Bologna 75' | - | - | - |
| 10-11 | Sassuolo 1-1 Milan | 0-0 | Milan 63', Sassuolo 68' | - | Sassuolo (Draw, -1, 68') | - |
| 10-11 | Cagliari 1-1 Juventus | 1-0 | Cagliari 20', Juventus 81' | Juventus 81' | Juventus (Draw, -1, 81') | - |

**Lessons (10-11 Oct, 8 matches):**
1. **3 draws (8 me se): Como 0-0 Roma, Sassuolo 1-1 Milan, Cagliari 1-1 Juventus.** Draw base 27.6% hai, yahan 37.5% — chhote sample ka blip. **Teeno me common:** (a) away side bari team thi (Roma/Milan/Juve) jo jeet nahi saki; (b) teeno me total goals <= 2; (c) 2 me ek team ne shots par hukumat ki lekin jeet nahi saki — Como 19 vs 9, Juventus 21 vs 5 (Section 14.4: 1.5x shots wali team ~52.8% jeetti hai, ~26.7% draw); (d) 1-1 dono me goal ka order: Milan 63' phir Sassuolo 68' (5 min me jawab); Cagliari 20' phir Juventus 81' (late equalizer); (e) Roma 53' me red ke baad bhi 0-0 bachayi. **'Kyun' ka baqi jawab** (finishing, goalkeeper — Cagliari ke GK ke 9 saves) data se sirf describe hota hai, causation nahi.
2. **2-1 results:** Genoa 2-1 Fiorentina (Genoa 7', 15'; Fiorentina 73') aur Bologna 2-1 Lecce (Bologna 17', Lecce 64', Bologna 75'). Base: 2-1 wale matches me winner ne pehla goal 63.5% kiya, match ke dauran lead 33.0% me gayi, haarne wali team ka goal 60' ke baad 36.6% me aaya.
3. **3-1 Lazio-Monza:** HT 2-0, Monza red 35', Monza ka goal 46' (HT ke turant baad), Lazio ka 3rd 88'. Base 3-1: winner HT par aage 69.6%, haarne wali team ka goal 2nd half me 58.9%, winner ka aakhri goal 76'+ me 48.2%.
4. **Late goals (3/8):** Napoli 90' (3-0), Lazio 88' (3-1) — dono 'lead barhai'; Juventus 81' — late equalizer. Base 36.5% matches me 81'+ goal.
5. **Comebacks:** sirf 2 draws (Sassuolo 68', Juventus 81'), koi comeback win nahi. Deficit dono me 1 goal; Sassuolo ne 5 min ke andar jawab diya.
6. **Shots on target > total shots:** Bologna (7 shots, 5 on target) ne Lecce (17 shots, 3 on target) ko haraya; Napoli ke 19 vs 17 shots the lekin 8 vs 1 on target (3-0). Section 14.4 me on-target dominance ka rate dekhen.
7. **Red cards:** Roma (53') ne 0-0 bachaya; Monza (35') 1-3 haara.

### 12 Oct 2026 (naye)
| Date | Match | HT | Goals | 81+ goals | Comeback | Red card |
|---|---|---|---|---|---|---|
| 10-12 | Atalanta 3-1 Venezia | 3-1 | Atalanta 4', 6', 30'; Venezia 37' | - | - | Atalanta (89') |
| 10-12 | Torino 2-1 Udinese | 1-1 | Torino 36'; Udinese 43'; Torino 67' | - | - | - |

### 16 Oct 2026 — user ke sawal: "yeh aisa kyun hua?" (10-11 Oct, Flashscore stats ke saath)
Numbers Section 21 se hain (16 Oct ke data par; rebuild par Section 21 khud update hota hai). **Aam** = purane matches me yeh aksar hota hai; **surprise** = kam hota hai.

| Match | Sawal | Purane matches (Serie A / teeno) | Match stats (xG, SOT) | Faisla |
|---|---|---|---|---|
| Inter 3-0 Parma | 2nd half me goal kyun nahi? | HT 3+ lead → 2nd half 0 goal: 26% / 21% | xG 2.42-0.46, SOT 6-2. Inter ne 61' par Lautaro, Thuram, Calhanoglu nikaal diye | Thora surprise. Match 31' par khatam tha; Inter ne "game management" kiya, aur Parma ke paas khatra nahi tha (xG 0.46) |
| Napoli 3-0 Frosinone | 90+4' goal kyun? | Home 2-0 at 80' → aur goal: 39% / 41%; 90'+ goal: 18% / 21% | xG 3.12-1.01, SOT 8-1 | Aam. Napoli ka dabaav aakhir tak raha; Frosinone ke 17 shots me sirf 1 on target tha |
| Como 0-0 Roma | Red card ke bawajood goal kyun nahi? | 0-0 HT + red → FT 0-0: 25% / 24% (bina red 25%) | Como 19 shots, 4 on target, 4 big chances miss; Roma GK ne 1.25 goal bachaye | Red se goal zaroori nahi; 10 aadmi wali Roma ne 34% ball ke saath defend kiya. Finishing + GK = 0-0 |
| Lazio 3-1 Monza | BTTS kyun hit, aur 88' goal kyun? | Home 2-0 HT → BTTS: 51%; 2-1 at 80' → aur goal: 37% / 41% | xG 1.84-1.76 (barabar!), SOT 7-6 | Aam. Monza ne 46' me goal kiya aur poore match me khatarnak rahi. 88' goal: Monza barabari ke liye aage aayi, aur sub Pinamonti ne goal kiya |
| Lecce 1-2 Bologna | Comeback phir 1-2 kyun, BTTS kyun? | 0-1 HT → BTTS 57%, away jeet 61%; 1-1 at 65' → koi jeeta 51% | Bologna ke 62' subs; Enem (sub) ne 75' winner kiya | Aam. HT par peeche wali home team aksar goal karti hai, lekin away team phir bhi 61% jeetti hai |
| Sassuolo 1-1 Milan | Over 2.5 di thi, Under kyun hit? | 0-0 HT → Under 2.5: 84% / 83%; 1-1 at 70' → aur goal nahi: 49% | Total xG 2.37 (band 2.0-2.49 = Over sirf 41%), SOT 10 | Pre-match Over ~coin-flip tha; HT 0-0 ke baad sirf ~16% bacha. Milan ne 3 big chances miss kiye |
| Cagliari 1-1 Juventus | Comeback kyun, Under kyun? | Home 1-0 HT, 1-1 at 81' → aur goal nahi: 65% / 58% | Juventus 21 shots vs 5 | Aam. Bari away team HT par peeche ho to aksar barabar karti hai (Kolo Muani 81'). 81' ke baad Serie A me 1-1 ruk jata hai |

**Sabaq (agle matches ke liye):**
1. **Serie A me HT 0-0 = Under ki taraf.** 84% matches Under 2.5 par khatam hote hain. Over 2.5 pre-match tab hi do jab odds me value ≥ +5% ho (Section 11); live me HT 0-0 par Over hold karna value nahi.
2. **Total xG 2.0-2.5 wale "barabar" matches** (Sassuolo-Milan 1.19-1.18) draw aur Under ki taraf jhukte hain. xG farq < 0.3 → draw ~35% (Section 21.2).
3. **Red card ≠ goals.** 10 aadmi wali team defend karti hai, aur 0-0 HT + red ke baad bhi ~25% FT 0-0 hota hai. Red ke baad "Over" mat lagao; pehle SOT/xG dekho.
4. **HT 3-0 ke baad 2nd half:** ~79% me goal aata hai, lekin jab aage wali team 60' par top players nikaal de aur dog ka xG < 0.5 ho, to "2nd half Under 1.5" behtar hai.
5. **Late goal (80'+) ka asal maqsad:** peeche wali team aage aati hai to counter par goal (Lazio 88', Napoli 90+4'). Home 2-0 / 2-1 at 80' → aur goal ~40%, yaani 60% me nahi aata. Late-goal bet sirf 2.40+ odds par value hai.

### 16 Oct 2026 — Frosinone 4-2 Sassuolo
| Date | Match | FT | Goals | Note |
|---|---|---|---|---|
| 10-16 | Frosinone 4-2 Sassuolo | 4-2 (HT 3-2) | Frosinone 9', 26', 30', 57'; Sassuolo 15', 37' | Pre-match O2.5 1.40; hamari Under 3.5 ❌; xG 2.08-1.92, SOT 10-6 |

**User ka sawal: "60' ke baad goal kyun nahi aaya? Kya rule bana dein ke itne goal ho jayein to 60' ke baad goal nahi aata?"**
Data (teeno leagues, 3,232 matches jin ke goal minutes poore hain):

| 60' tak goals | n | 60' ke baad **koi goal nahi** | 60' ke baad goal aaya |
|---|---|---|---|
| 0 | 636 | 39% | 61% |
| 1 | 1003 | 32% | 68% |
| 2 | 825 | 31% | 69% |
| 3 | 498 | 36% | 64% |
| 4 | 195 | 31% | 69% |
| 5 | 58 | 26% | 74% |
| 6+ | 17 | 41% | 59% |
| **5+ (mila kar)** | **75** | **29%** | **71%** |

Serie A akela: 5+ goal by 60' (n=19) → 42% no goal; 4 goal (n=66) → 41%.

**Faisla:** "6 goal ke baad 60' ke baad goal nahi aata" **rule galat hai** — 5+ goal wale matches me bhi **~71% baar 60' ke baad aur goal aata hai**. Frosinone-Sassuolo wala match "surprise" side tha (~29-41%). **Is match se rule nahi banega.** Agar aisi haalat me "no more goal" ki market @2.50+ mile tab hi value (fair ~2.4-3.4).
**Kyun is match me ruk gaya (mumkin wajah):** Frosinone 4-2 aage tha — ghar ki team ne lead bachane ke liye defend kiya; 6 goal ke baad dono teams thak jati hain aur subs aate hain. Lekin yeh har baar nahi hota.

### 17-18 Oct 2026 — Venezia 1-0 Napoli, Bologna 1-3 Inter, Roma 2-0 Genoa, Udinese 0-3 Lecce
(Monza 4-0 Cagliari 19 Oct aur Parma 0-3 Torino: poora Flashscore dump dobara chahiye — abhi databook me nahi. Monza pre-match: 1X2 2.62/3.30/3.10, O2.5 2.16 / U2.5 1.80, hamari Draw bet ❌. Parma-Torino pre-match 3.45/3.05/2.25, Torino fav jeeti.)
| Date | Match | FT (HT) | Goals | xG | SOT | Note |
|---|---|---|---|---|---|---|
| 10-17 | Venezia 1-0 Napoli | 1-0 (0-0) | Venezia 49' | 0.98-2.36 | 4-10 | Napoli 29 shots, De Bruyne penalty miss 68', 4 big chances miss, GK Venezia 1.58 xGOT me 1 goal rok ke +0.58 |
| 10-18 | Bologna 1-3 Inter | 1-3 (1-1) | Bologna 10', Inter 44', 69', 83' | 1.00-3.16 | 4-8 | Inter ne 2nd half 3 big chances me 2 goal; 81' goal offside |
| 10-18 | Roma 2-0 Genoa | 2-0 (0-0) | Roma 50', 68' | 1.33-0.47 | 5-1 | Genoa ke sirf 1 SOT (xGOT 0.07) |
| 10-18 | Udinese 0-3 Lecce | 0-3 (0-2) | Lecce 11', 33', 86' | 0.54-3.47 | 2-11 | Lecce 11 SOT, 2 woodwork, 8 big chances |

**Sawal 1 — Venezia-Napoli: BTTS No / Under 2.5 kyun, favourite kyun haara, kya odds trap thi?**
- Pre-match signals jo data me the: Napoli away fav ~1.75-1.95 (live 31' par 0-0 me 1.93). Base: away fav 1.60-2.10 ka haarna sirf 20%, jeetna 57% (n=451). 0-0 HT par fav<=2.0: fav jeeta 49%, draw 39%, haara 12%, BTTS No 75%, Under 2.5 82% (n=523). Yaani "Napoli ka 0-0/1-0 se haarna" 12% wala outcome hai, lekin BTTS No + Under 2.5 pehle se majboot the.
- Match ke andar signal: 31' par 0-0, shots 3-3, corners 0-4, mazeed Under 2.5 live 1.41. Final: Napoli xG 2.36, 29 shots, 10 SOT, penalty miss, 4 big chances miss, Venezia 1 SOT aur 1 goal (xG 0.98, 49').
- Haar ki wajah: finishing + GK + penalty miss. Odds ne "trap" nahi kiya: Napoli ka favourite hona sahi tha, process (xG) sahi tha, sirf natija 12%-wale hisse me gaya. **Result se rule nahi banta; process se banta hai.**
**Sawal 2 — Bologna-Inter: comeback aur 83' goal**
- Inter ke xG 3.16 vs 1.00, 7 big chances vs 3. Bologna ka 10' goal xG se zyada tha. Inter 1-1 HT se 3-1 jeeta — barabar ke HT par stronger side ki 2nd half me goal ki chance zyada. Data: HT 1-1 me 2nd half me 2+ goal 46%, 80'+ goal 42% (n=316).
- 83' goal: sab matches me 80'+ goal 42%, 85'+ 32% (n=3105); 2-goal gap par bhi 80'+ goal 44%. Late goal "surprise" nahi, aam hai. Bologna aage aayi (79' me subs), Inter ne counter kiya.
**Sawal 3 — Roma-Genoa: BTTS No, Under 2.5, 70' ke baad goal kyun nahi**
- Roma xG 1.33 vs 0.47, Genoa xGOT 0.07 (1 SOT): Genoa ka goal ka rasta hi nahi tha → BTTS No signal tha. HT 0-0 par BTTS No 76%, Under 2.5 83%.
- 2-0 ke baad 68'-90': 41% me koi goal nahi aata (n=439), 59% me aata hai — yahan "no goal" aam hissa tha, rare nahi. Roma ne 65'-83' subs se game control kiya.
**Sawal 4 — Udinese-Lecce: BTTS No, 86' goal, pre-match signals sahi the?**
- Lecce xG 3.47 vs 0.54, 11 SOT vs 2 (Udinese ke sirf 2 SOT). HT 2-0: baad me 3+ total goals 84%, loser ka goal 52% (BTTS Yes 52% — yaani BTTS No yahan coin-flip tha), 80'+ goal 45% (n=365). 86' goal normal.
- Pre-match ke signals: is match ke odds is chat me nahi mile (screenshot nahi), isliye "sahi mile ya nahi" ka faisla nahi kar sakta. Yeh gap hai: **har pick se pehle odds screenshot save karo.**

**Naye rules (data se):**
1. **HT 0-0 → BTTS No ~75%, Under 2.5 ~83%** (3 leagues, n=931). Live: HT 0-0 par Over/BTTS Yes ke liye 2.40+ odds chahiye.
2. **Fav (<=2.0) ke 0-0 HT par haarne ka chance sirf 12%** — par jeet 49%, draw 39%. Fav par "win" ki jagah "Double chance / Draw No Bet" 0-0 par behtar. Xg ke bina result se rule mat banao.
3. **Late goal (80'+) 42%, 85'+ 32%** — late-goal bet sirf 2.40+ par; 83'/86' ke goal ko pattern mat samjho.
4. **2-0 ke baad "no more goal" 41%** — 59% me aur goal aata hai. 70' ke baad no-goal ko rule mat banao.
5. **HT 2-0 me BTTS No sirf 48%** (loser 52% me goal karta hai). Lecce-jaise dominant xG (3.47 vs 0.54) me BTTS No aur 3+ goals dono sach the.
6. **Process vs natija:** Napoli xG 2.36 + 29 shots ke baad bhi haara — 4 big chance miss + penalty miss. Aise match me hamari fav ki bet hari, lekin analysis galat nahi tha. Result ke baad rule tab hi banao jab data me n>=50 ho.
