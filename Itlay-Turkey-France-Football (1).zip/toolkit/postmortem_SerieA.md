## 15. Post-mortem — 12 Oct 2026 ke matches (pre-match → live → result)

### 15.1 Atalanta 3-1 Venezia (HT 3-1)
- **Pre-match odds:** 1.50 / 4.33 / 6.25. **Odds history (Section 2 neighbour search):** teeno leagues ke 276 aise matches: home 61%, draw 23%, away 16%; Over 2.5 55%, BTTS 52%. Serie A ke 112: home 57%, Over 2.5 52%, BTTS 48%.
- **Hamari pre-match picks:** Atalanta win @1.50 (~67%) → ✅ **jeeta**. BTTS No @2.20 (~55%) → ❌ **haara** (Venezia ne 37' me goal kiya). Under 3,3.5 @1.80 → ❌ (4 goals).
- **Live (27', 2-0):** humne kaha Atalanta jeetegi ~88-90% ✅, kam se kam 3 goals ~91% ✅, 4+ goals ~58% ✅ (4 aaye), top scores 3-0/4-0/2-1/3-1 ✅ (3-1 aaya). Live pick **Under 4.5 @1.93 → ✅ jeeta** (4 goals, 30' ke baad sirf 1 goal). BTTS No @2.44 → ❌.
- **Data ab:** teeno leagues me jab fav 27' par 2-0 aage tha (152 matches): fav 89% jeeta, 3+ goals 92%, 4+ goals 66%, 5+ 37%, dog ne goal kiya 59%.
- **Kyun aisa hua:** 6 minute me 2 goal + 30' tak 3-0 → Atalanta ne baqi match control kiya (62% possession Venezia ke paas tha, lekin Atalanta ke 11 shots on target). Venezia ne 3-0 ke baad "consolation" goal kiya — 2+ goal peeche wali team aksar ek goal karti hai.
- **Lesson:** (1) jab dog 2+ goal peeche ho to **BTTS No mat lagao** — 59% me dog goal kar deta hai. (2) Under (current + 2.5) jaisa line, jab fav 3 goal aage aur 60+ minute baqi hon, achha raha. (3) 1.80+ wali BTTS No ki value pre-match me thi hi nahi (data 48-52% BTTS keh raha tha).

### 15.2 Torino 2-1 Udinese (HT 1-1)
- **Pre-match odds:** 2.375 / 3.10 / 3.30. **Neighbour search:** teeno leagues ke 410 matches: home 46%, draw 29%, away 25%, Over 2.5 45%, BTTS 53%. Serie A ke 182: home 43%, draw 34%, Over 2.5 43%.
- **Hamari picks:** pehle Over 2.5 @2.10-2.23 (~48%, coin-flip) → ✅ (3 goals). Aakhri post Udinese +0.25 @1.85 (~62%) → ❌ **haara** (Torino 67' me jeeta).
- **Kyun:** Udinese ke paas 62% possession aur 15 shots the, lekin sirf 2 on target; Torino ne 8 shots me 3 on target se 2 goal kiye. HT 1-1 ke baad Section 7 ke mutabiq aur goal ~70%+ hota hai — wohi hua.
- **Lesson:** (1) neighbour search me Udinese ka "na haarna" ~54% tha, market bhi ~55% — **edge zero tha**, isliye Coin-flip zone sahi tha; post karna majboori tha, value nahi. (2) Possession + shots ≠ jeet (Section 14.4: shots me hukumat wali team bhi ~18-21% haarti aur ~27% draw khelti hai).

### 15.3 Sassuolo 1-1 Milan (11 Oct, HT 0-0) — user ki Over 2.5 prediction
- **Pick:** Over 2.5 → ❌ (1-1). Pre-match odds databook me nahi hain, is liye pre-match value check nahi ho saka.
- **Kya hua:** HT 0-0; Milan 63' (Rabiot), Sassuolo 68' (Odenthal, comeback draw). 1-1 at 70' ke baad goal nahi aaya.
- **Data:** Serie A me 0-0 HT → 84% Under 2.5. Total xG 2.37 (band 2.0-2.49 → Over 2.5 sirf 41%). SOT 10 (band 8-10 → 57%). Milan ne 3 big chances miss kiye.
- **Lesson:** (1) Serie A ka Over 2.5 base sirf ~48% hai, to bina value ke Over 2.5 mat do. (2) Do barabar teams (xG 1.19 vs 1.18) → draw aur Under ki taraf. (3) HT 0-0 par Over wali bet ka asal chance ~16% reh jata hai — live me hedge/cash-out ka waqt.

### 15.3 Frosinone 4-2 Sassuolo (16 Oct 2026) — hamari galti
- **Pre-match odds:** 2.30 / 3.80 / 2.70; O2.5 **1.40**, O3.5 2.00 / U3.5 1.80, BTTS 1.36. Market ne goals bohat zyada price kiye the (O2.5 1.40 ≈ 3.3 goal ki umeed).
- **Hamari pick:** **Under 3.5 @1.80** (hum ne ~62% kaha) → ❌ **haari, 6 goal**. Under 3.25 @2.00 → ❌.
- **Kya hua:** Calo 9' (1-0), Berardi 15' (1-1), Raimondo 26', 30' (3-1), Thorstvedt 37' (3-2) → **HT 3-2 (5 goal 1st half me)**; Raimondo 57' (4-2, hat-trick). 58'-80' dono taraf 9 subs; Bowie (Sassuolo) yellow 82'. 17' Kvernadze (Sassuolo) ka goal offside.
- **Stats:** xG 2.08 – 1.92 (total 4.0); shots 21 – 14; **on target 10 – 6**; xGOT 4.51 – 3.05; big chances 5 – 4; possession 42 – 58%; corners 5 – 4.
- **Odds kis taraf the (match se pehle):** Frosinone 2.30 (fav, ~41%) / Draw 3.80 / Sassuolo 2.70; **O2.5 1.40 (~70%), O3.5 2.00**, BTTS Yes 1.36 (~72%). **Market dono baaton par sahi tha**: Frosinone jeeta, aur bohat goal + BTTS aaye. Hum ne market ke ulat Under pakra — galti yahi thi.
- **Galti kyun hui:**
  1. **Market ke khilaf gaye bina pukhta wajah ke.** O2.5 @1.40 Serie A me nadir hai. Hum ne kaha "market ne Over zyada price kiya", lekin bookmaker ke paas team news thi: **Sassuolo ka defender Leysen (ACL) bahar** tha, Sassuolo 1.7 goal/match kha raha tha. Hum ne injuries check nahi ki thi.
  2. **Chhota sample par bharosa:** Serie A "O2.5 ≤1.50" bucket sirf n=25 tha (rule: n ≥ 50). Teeno leagues ka bara bucket (n=207) Under 3.5 sirf **53%** deta tha → 1.80 par value ~−5%, yani **no bet** hona chahiye tha.
  3. Season avg (Serie A 2026-27 Under 3.5 73%) ko weight diya, jab ke yeh match "average" nahi tha — market ki price hi bata rahi thi ke yeh khula match hai.
- **Lessons:**
  1. **Jab O2.5 opening ≤1.45 ho, Under mat lagao** jab tak n ≥ 50 wala bucket +5% value na de. Market ki itni strong price ke khilaf jaane se pehle team news (defenders/keeper injury) dekho.
  2. **Sample rule sakhti se:** n < 50 → us bucket par pick nahi; bara (teeno leagues) bucket use karo.
  3. **Injury/line-up check lazmi** — 3-baar check ke Check 2 me.
  4. **Market ki direction follow karo jab woh extreme ho:** BTTS Yes ≤1.40 aur O2.5 ≤1.45 dono saath hon to bookmaker "open match" keh raha hai — Under/BTTS No sirf tab jab bara sample +5% value de.
- **60' ke baad goal kyun nahi:** 57' par 4-2 ke baad Frosinone ne lead bachayi; 58'-80' me 9 subs (rhythm toota), aur Sassuolo ke attackers (Thorstvedt, Kvernadze) bahar gaye. Data: HT 4+ goal → 2nd half me sirf 0-1 goal: Serie A 74% (n=27), teeno leagues 53% (n=98); 60' tak 5+ goal → aur goal nahi sirf 29% (n=75). **Yaani 'aur goal nahi' surprise side thi — rule nahi banega.**
