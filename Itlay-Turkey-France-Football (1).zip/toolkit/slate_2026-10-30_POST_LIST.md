# POST-READY LIST — 30 Oct se 2 Nov 2026 (gate: pick_gate.py, Section 63)

**KOI STRONG BET NAHI.** 24 match me gate ne 0 STRONG nikali. Niche sirf LEAN / LEAN-A (stake 0.5%) hain, ranking ke saath. Jo bhi post ho, "strong" ya "pakki" lafz nahi (Section 63-7).

## POST KARNE WALI BETS (gate ki ranking, behtar se kamzor)

| # | Match | Day PKT | Bet | Odds | Chance (cons/med) | Gate min odds | 5-pattern | Tier |
|---|---|---|---|---|---|---|---|---|
| 1 | Milan vs Inter | SUN 1 Nov 00:45 | Inter win | 2.00 | 47% / 51% | 2.38 | saath | LEAN |
| 2 | Istanbul BB vs Samsunspor | SUN 1 Nov 18:00 | Istanbul BB win | 1.80 | 54% / 58% | 1.88 | saath | LEAN-A |
| 3 | Frosinone vs Torino | SUN 1 Nov 19:00 | Frosinone win | 2.15 | 47% / 48% | 2.35 | saath | LEAN-A |
| 4 | Nice vs Rennes | FRI 30 Oct 23:00 | Rennes win | 2.50 | 45% / 45% | 2.46 | neutral | LEAN (value, kam hit-rate) |
| 5 | Juventus vs Napoli | SUN 2 Nov 00:45 | Juventus win | 2.30 | 40% / 46% | 2.86 | neutral | LEAN (value, kam hit-rate) |
| 6 | Lazio vs Cagliari | SUN 1 Nov 19:00 | BTTS Yes | 2.00 | 42% / 53% | 3.00 | neutral | LEAN (value, kam hit-rate) |
| 7 | Paris FC vs Monaco | SUN 1 Nov 21:15 | Paris FC win | 2.30 | 40% / 47% | 2.86 | neutral | LEAN (value, kam hit-rate) |
| 8 | Kocaelispor vs Rizespor | SAT 31 Oct 18:00 | Kocaelispor DNB | 1.83 | 39% / 72% | 3.18 | neutral | LEAN (value, kam hit-rate) |

**Saaf baat:** #1, #2, #3, #5, #6, #7, #8 ke actual odds gate ke min odds se KAM hain. Yani conservative chance par yeh +EV nahi, sirf median chance par hain. Sab se kam kharab #4 (Rennes 2.50 vs min 2.46) hai. Agar sirf 3 post karni hain: #1, #2, #3 (teeno 5-pattern saath). Stake har ek par 0.5%.

**Ek rule-sawal (Section 63-0: gate khud nahi badla):** Lille vs Lens me **Lens DNB @1.85** sab se behtar cells wala market tha — chance 62%/67%, 6 cells pass / 0 fail, edge +14% (conservative) / +24% (median), odds min 1.80 se oopar. Gate ne isko block kiya kyunke DNB ko "win-type" mana jata hai aur venue ppg gap −0.25 tha, jo ULTA ki hadd (−0.20) se sirf 0.05 aage nikla. Section 63-2 me DNB ka family likha nahi hai. Agar aap kaho ke DNB ko DC-type mana jaye (ULTA hadd −0.50), to yeh pick NEUTRAL ban kar is hafte ki sab se achhi bet ban jati hai. Faisla aap ka; main ne khud nahi badla.

---

## HAR MATCH KA 50-WORD ANALYSIS

### FRIDAY (30 Oct, PKT)

**Le Havre vs PSG — 23:00 — NO BET**
Le Havre have won five of twenty home games and sit bottom on form. PSG travel 12-4-4 with 1.8 goals per away game. Odds 1.30 leave nothing: the gate found no market above 1.80 that clears its threshold. Goal-bullish pricing blocks every Under and BTTS No line here.
*Closest: Draw @6.00 (16%/17%). Scores: 0-2 (10%), 1-2 (9%).*

**Nice vs Rennes — 23:00 — LEAN 0.5%: Rennes win @2.50**
Rennes away form is 8-4-8 but they concede 2.1 per trip, and Nice have drawn ten of twenty at home. Goal estimate 3.22 with H2H averaging 3.00. Three cells pass, none fail, and the price sits just above the gate minimum of 2.46. Low hit-rate value bet, not a confident call.
*5-pattern neutral. Scores: 1-1 (11%), 1-2 (9%).*

**Konyaspor vs Galatasaray — 22:00 — NO BET**
Galatasaray are 13-1-6 on the road and priced 1.52, below the 1.80 floor. Konyaspor's home record is a flat 7-7-6 with just 1.05 goals scored. The only near market, Konyaspor or Draw at 2.49, reads 5-pattern ulta, so rising odds still would not make it a bet.
*Closest: Konyaspor or Draw @2.49 (35%/42%), ulta. Scores: 1-2 (10%), 0-2 (10%).*

### SATURDAY (31 Oct, PKT)

**Bologna vs Monza — 19:00 — NO BET**
Bologna have a poor 3-6-11 home record, yet Monza are worse away at 1-3-16 while shipping 2.4 goals a game. H2H averages only 1.75 goals. The closest market, Monza or Draw at 2.15, is 5-pattern ulta with zero cells passing, so the gate blocks it outright.
*Closest: Monza or Draw @2.15 (46%/49%), ulta. Scores: 1-1 (11%), 1-0 (11%).*

**Udinese vs Roma — 22:00 — NO BET**
Udinese have lost eleven of twenty at home and score 0.75 a game. Roma travel well at 9-3-8 but 1.53 is under the odds floor. Goal estimate is a low 2.30. Udinese or Draw at 2.50 is the nearest market and it reads ulta, needing 3.22 anyway.
*Closest: Udinese or Draw @2.50 (35%/40%), ulta. Scores: 1-2 (10%), 0-2 (10%).*

**Lille vs Lens — 01:05 — NO BET (rule question above)**
Lille are 9-7-4 at home conceding one a game; Lens travel 8-5-7 scoring 1.8. This is the only non-goal-bullish Ligue 1 fixture of the three. Lens Draw No Bet at 1.85 passes all six cells with a large edge, but the 5-pattern rule classes it ulta.
*Closest: Lens DNB @1.85 (62%/67%), ulta by current rule. Scores: 1-1 (12%), 0-1 (9%).*

**Erzurum vs Corum — 15:30 — NO BET (data kam)**
Both clubs are newly promoted, so the venue samples are four and five matches, under the ten-game minimum in rule 57-E. Goal estimate 3.30 and Corum's 2.4 away goals do point over, but the gate will not price a market on this little history.
*Closest: Over 2.5 @1.95 (45%/50%), saath. Scores: 1-1 (13%), 1-0 (10%).*

**Kocaelispor vs Rizespor — 18:00 — LEAN 0.5%: Kocaelispor DNB @1.83**
Kocaelispor are 9-5-6 at home conceding only 0.7, while Rizespor draw often away at 5-8-7. The draw-void market protects the most likely single scoreline. But the chance band runs 39% to 72%, which is very wide, and 1.83 sits well under the 3.18 minimum.
*5-pattern neutral. Scores: 1-1 (13%), 1-0 (10%).*

**Fenerbahce vs Goztepe — 21:00 — NO BET**
Fenerbahce are 13-6-1 at home with 2.65 goals a game, but 1.30 is far below the odds floor. Goztepe's 6-8-6 away record is stubborn rather than weak. Goal estimate 3.20 leans over, yet market pricing at 1.44 already blocks every Under and the over lines fail.
*Closest: Draw @5.25 (15%/17%). Scores: 2-0 (10%), 2-1 (10%).*

### SUNDAY (1 Nov, aur 2 Nov 00:45 wale, PKT)

**Milan vs Inter — 1 Nov 00:45 — LEAN 0.5%: Inter win @2.00 (sab se behtar)**
Inter's away record is the standout number: 14-4-2 with 2.05 scored and 0.9 conceded. Milan are solid but not dominant at 10-5-5. The venue gap favours Inter, so the 5-pattern is saath. Three cells pass and three fail, and 2.00 is under the 2.38 minimum.
*5-pattern saath. Scores: 1-1 (11%), 1-2 (9%).*

**Como vs Venezia — 16:30 — NO BET**
Como are 11-6-3 at home conceding 0.75, and Venezia have not won away in twenty, sitting 0-8-12. The market reflects all of it at 1.30. Goal pricing of 1.41 blocks Unders, and no market above 1.80 clears the gate. Draw at 6.00 is the nearest, at 16%.
*Closest: Draw @6.00 (16%/17%). Scores: 2-0 (10%), 2-1 (9%).*

**Frosinone vs Torino — 19:00 — LEAN 0.5%: Frosinone win @2.15**
Frosinone are 9-3-8 at home with 70% of those games going over 2.5, while Torino travel 4-6-10 scoring just one. The venue gap of +0.60 makes the 5-pattern saath. Only one cell passes against three failing, and 2.15 is under the 2.35 minimum. Thin but aligned.
*5-pattern saath. Scores: 1-1 (10%), 2-1 (9%).*

**Lazio vs Cagliari — 19:00 — LEAN 0.5%: BTTS Yes @2.00 (value, kam hit-rate)**
Lazio score 1.4 at home but also concede 1.25, and Cagliari have found the net in most away trips while shipping 1.6. Six cells passed with none failing on the median read. The conservative chance is only 42%, so this loses more often than it wins.
*5-pattern neutral. Scores: 2-0 (12%), 1-0 (12%).*

**Lecce vs Genoa — 22:00 — NO BET**
Both sides are poor in front of goal: Lecce score 0.7 at home, Genoa 0.9 away, and the H2H averages 1.33. The goal estimate of 2.17 actually leans under, which makes the closest market, Over 2.25 at 2.08, 5-pattern ulta despite four cells passing.
*Closest: Over 2.25 @2.08 (50%/56%), ulta. N2 draw alert @3.00 optional. Scores: 1-1 (13%), 0-1 (13%).*

**Juventus vs Napoli — 2 Nov 00:45 — LEAN 0.5%: Juventus win @2.30 (value, kam hit-rate)**
Juventus have lost only two of twenty at home and concede 0.7, but they draw eight, which caps the win chance at 40% conservative. Napoli travel 10-4-6. The goal estimate of 2.40 is low for a tie like this. Price 2.30 sits well under the 2.86 minimum.
*5-pattern neutral. Scores: 1-1 (13%), 1-0 (11%).*

**Troyes vs Le Mans — 1 Nov 00:45 — NO BET (data kam)**
Both promoted sides have only four venue games on record, under the ten-match floor in rule 57-E. The samples that exist are alarming: Troyes concede 2.75 at home, Le Mans 2.0 away, giving a 3.38 goal estimate. Not enough history for the gate to price anything.
*Closest: Troyes win @2.35 (44%/47%), ulta. Scores: 1-1 (12%), 1-0 (9%).*

**Strasbourg vs Auxerre — 19:00 — NO BET (trigger qareeb)**
Strasbourg are 10-4-6 at home scoring 1.7, and Auxerre are 3-6-11 away conceding 1.85, so the 5-pattern is saath at +0.95. But zero cells pass and the 1.80 price is under the 1.88 minimum. If the home win drifts to 1.88 it becomes a LEAN.
*Closest: Strasbourg win @1.80 (54%/54%), saath. Trigger 1.88. Scores: 1-1 (11%), 2-1 (10%).*

**Lyon vs Angers — 21:15 — NO BET**
Lyon are 14-2-4 at home and Angers have lost eleven of twenty away while scoring 0.75, so 1.40 is fair rather than generous. Over pricing at 1.56 blocks the Under family. Nothing above 1.80 passes; the nearest is the draw at 5.00 on 16%.
*Closest: Draw @5.00 (16%/17%). Scores: 2-0 (11%), 2-1 (10%).*

**Paris FC vs Monaco — 21:15 — LEAN 0.5%: Paris FC win @2.30 (value, kam hit-rate)**
Paris FC score 1.7 at home but leak 1.45, and Monaco's away record is a middling 8-5-7. The goal estimate of 3.17 and both sides over 60% for over 2.5 point to goals. Four cells passed, four failed, and 40% conservative means this loses most weeks.
*5-pattern neutral. Scores: 1-1 (12%), 1-0 (9%).*

**Marseille vs Toulouse — 2 Nov 00:45 — NO BET (trigger qareeb)**
Marseille are 12-4-4 at home with 2.35 goals a game and 75% over 2.5; Toulouse travel 6-6-8. The 5-pattern is saath on a +0.80 gap. But the home win at 1.92 reads minus 10% conservative, failing the gate. Trigger for a LEAN is 2.28.
*Closest: Marseille win @1.92 (47%/48%), saath. Trigger 2.28. Scores: 1-1 (10%), 2-1 (10%).*

**Amedspor vs Eyupspor — 15:30 — NO BET (data kam)**
Amedspor are newly promoted with only five home games, so rule 57-E applies even though that record is a perfect 5-0-0 with 2.8 goals a game. Eyupspor are 3-5-12 away. The gate will not price so small a sample, and the closest market reads ulta.
*Closest: Under 3 @1.82 (46%/55%), ulta. Scores: 2-0 (13%), 1-0 (11%).*

**Istanbul BB vs Samsunspor — 18:00 — LEAN 0.5%: Istanbul BB win @1.80**
Istanbul BB are 11-5-4 at home scoring 2.15, while Samsunspor travel 6-5-9 and concede 1.7. The venue gap of +0.75 makes the 5-pattern saath, and 54% is the highest conservative chance of the weekend. Still, no cells passed and 1.80 undercuts the 1.88 minimum.
*5-pattern saath. Scores: 1-1 (11%), 2-1 (10%).*

**Trabzonspor vs Gaziantep — 18:00 — NO BET**
Trabzonspor are 12-6-2 at home and Gaziantep 6-5-9 away, so 1.37 carries no value. The goal estimate of 3.02 and an H2H average of 3.33 both lean over, but the 1.43 over price blocks Unders and the over lines above 1.80 all fail on edge.
*Closest: Draw @5.40 (15%/17%). Scores: 2-0 (10%), 2-1 (10%).*

**Kasimpasa vs Besiktas — 21:00 — NO BET**
Kasimpasa draw nine of twenty at home and Besiktas travel 9-5-6, with Besiktas priced 1.58, under the floor. The H2H average of 3.00 hints at goals, but the goal estimate is only 2.55 and every over line fails on edge. No market clears the gate.
*Closest: Over 2.75 @1.85 (45%/52%). Scores: 1-1 (10%), 0-1 (10%).*

---

**Yaad rahe:** post se pehle team news (Section 51) khud dekho — gate injuries/suspension nahi dekhta. Odds screenshot ke asli odds hi use karo. Koi bet "pakki" nahi.

✅ 3x recheck: data · rules · maths
