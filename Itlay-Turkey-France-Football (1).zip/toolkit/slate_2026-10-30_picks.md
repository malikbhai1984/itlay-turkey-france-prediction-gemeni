# Slate 30-Nov-2026 se 2 Nov: gate picks (odds screenshot 30 Oct 10:41 PKT)

Sab odds `toolkit/slate_2026-10-30_odds.tsv.txt` me save hain; match ke baad post-mortem karna hai. Koi STRONG nahi: sirf LEAN 0.5%.

## JUMA RAAT (aaj, 30 Oct)

### Le Havre vs PSG (30 Oct 23:00 PKT, Ligue 1)
- FAISLA: **NO BET**
- 5-pattern: neutral
- Closest market: Draw @ 6.0 | chance 16%/17% | min odds 7.93 | cells 2 pass/4 fail
- Trigger odds: STRONG ke liye odds >= 8.33 (lekin chance 16% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 0-2 (10%), 1-2 (9%)
- Analysis (39 words): Le Havre home L20 5-9-6 (GF 1.05, GA 1.1); PSG away 12-4-4 (GF 1.8, GA 1.0). Goal estimate 2.48, H2H 6 games avg 3.33 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Draw @6.0, chance 16-17%, 5-pattern NEUTRAL.

### Nice vs Rennes (30 Oct 23:00 PKT, Ligue 1)
- FAISLA: **LEAN 0.5%** - Rennes win @ 2.5 | chance 45% (conservative) / 45% (median) | min odds 2.46 | tier LEAN [VALUE BET, kam hit-rate]
- 5-pattern: neutral
- Closest market: Rennes win @ 2.5 | chance 45%/45% | min odds 2.46 | cells 3 pass/0 fail
- Trigger odds: STRONG ke liye odds >= 2.58 (lekin chance 45% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (11%), 1-2 (9%)
- Analysis (37 words): Nice home L20 6-10-4 (GF 1.2, GA 1.45); Rennes away 8-4-8 (GF 1.7, GA 2.1). Goal estimate 3.22, H2H 6 games avg 3.00 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: LEAN Rennes win @2.5, chance 45-45%, 5-pattern NEUTRAL.

### Konyaspor vs Galatasaray (30 Oct 22:00 PKT, Super Lig)
- FAISLA: **NO BET**
- 5-pattern: ulta
- Closest market: Konyaspor or Draw @ 2.49 | chance 35%/42% | min odds 3.22 | cells 2 pass/2 fail
- Trigger odds: STRONG ke liye odds >= 3.38 (lekin chance 35% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-2 (10%), 0-2 (10%)
- Analysis (40 words): Konyaspor home L20 7-7-6 (GF 1.05, GA 1.0); Galatasaray away 13-1-6 (GF 1.8, GA 1.1). Goal estimate 2.48, H2H 6 games avg 2.83 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Konyaspor or Draw @2.49, chance 35-42%, 5-pattern ULTA.

## SATURDAY (PKT 31 Oct)

### Bologna vs Monza (31 Oct 19:00 PKT, Serie A)
- FAISLA: **NO BET**
- 5-pattern: ulta
- Closest market: Monza or Draw @ 2.15 | chance 46%/49% | min odds 2.27 | cells 0 pass/3 fail
- Trigger odds: LEAN ke liye odds >= 2.27 | STRONG ke liye odds >= 2.38 (lekin chance 46% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-1 (11%), 1-0 (11%)
- Analysis (40 words): Bologna home L20 3-6-11 (GF 0.8, GA 1.45); Monza away 1-3-16 (GF 0.85, GA 2.4). Goal estimate 2.75, H2H 4 games avg 1.75 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Monza or Draw @2.15, chance 46-49%, 5-pattern ULTA.

### Udinese vs Roma (31 Oct 22:00 PKT, Serie A)
- FAISLA: **NO BET**
- 5-pattern: ulta
- Closest market: Udinese or Draw @ 2.5 | chance 35%/40% | min odds 3.22 | cells 1 pass/1 fail
- Trigger odds: LEAN ke liye odds >= 3.22 | STRONG ke liye odds >= 3.38 (lekin chance 35% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-2 (10%), 0-2 (10%)
- Analysis (40 words): Udinese home L20 5-4-11 (GF 0.75, GA 1.15); Roma away 9-3-8 (GF 1.55, GA 1.15). Goal estimate 2.30, H2H 6 games avg 2.67 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Udinese or Draw @2.5, chance 35-40%, 5-pattern ULTA.

### Lille vs Lens (31 Oct 01:05 PKT, Ligue 1)
- FAISLA: **NO BET**
- 5-pattern: ulta
- Closest market: Lens DNB @ 1.85 | chance 62%/67% | min odds 1.80 | cells 6 pass/0 fail
- Trigger odds: STRONG ke liye odds >= 1.89 | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-1 (12%), 0-1 (9%)
- Analysis (37 words): Lille home L20 9-7-4 (GF 1.45, GA 1.0); Lens away 8-5-7 (GF 1.8, GA 1.4). Goal estimate 2.82, H2H 6 games avg 2.33 goals. Not goal-bullish. Gate: NO BET; closest Lens DNB @1.85, chance 62-67%, 5-pattern ULTA.

### Erzurum vs Corum (31 Oct 15:30 PKT, Super Lig)
- FAISLA: **NO BET** (data kam, 57-E: kisi team ke <10 match)
- 5-pattern: saath
- Closest market: Over 2.5 @ 1.95 | chance 45%/50% | min odds 2.55 | cells 1 pass/3 fail
- Trigger odds: LEAN ke liye odds >= 2.00 | STRONG ke liye odds >= 2.68 (lekin chance 45% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (13%), 1-0 (10%)
- Analysis (29 words): Erzurum home L20 3-0-1 (GF 1.0, GA 1.0); Corum away 2-1-2 (GF 2.4, GA 2.2). Goal estimate 3.30, no H2H. Not goal-bullish. Gate: NO BET, too little data (57-E).

### Kocaelispor vs Rizespor (31 Oct 18:00 PKT, Super Lig)
- FAISLA: **LEAN 0.5%** - Kocaelispor DNB @ 1.83 | chance 39% (conservative) / 72% (median) | min odds 3.18 | tier LEAN [VALUE BET, kam hit-rate]
- 5-pattern: neutral
- Closest market: Over 2.5 @ 1.9 | chance 48%/51% | min odds 2.21 | cells 0 pass/4 fail
- Trigger odds: LEAN ke liye odds >= 2.00 | STRONG ke liye odds >= 2.32 (lekin chance 48% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (13%), 1-0 (10%)
- Analysis (35 words): Kocaelispor home L20 9-5-6 (GF 1.05, GA 0.7); Rizespor away 5-8-7 (GF 1.45, GA 1.55). Goal estimate 2.38, H2H 2 games avg 2.00 goals. Not goal-bullish. Gate: LEAN Kocaelispor DNB @1.83, chance 39-72%, 5-pattern NEUTRAL.

### Fenerbahce vs Goztepe (31 Oct 21:00 PKT, Super Lig)
- FAISLA: **NO BET**
- 5-pattern: neutral
- Closest market: Draw @ 5.25 | chance 15%/17% | min odds 8.98 | cells 2 pass/7 fail
- Trigger odds: STRONG ke liye odds >= 9.43 (lekin chance 15% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 2-0 (10%), 2-1 (10%)
- Analysis (38 words): Fenerbahce home L20 13-6-1 (GF 2.65, GA 1.1); Goztepe away 6-8-6 (GF 1.3, GA 1.35). Goal estimate 3.20, H2H 4 games avg 2.75 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Draw @5.25, chance 15-17%, 5-pattern NEUTRAL.

## SUNDAY (PKT 1 Nov, aur 2 Nov 00:45 wale)

### Milan vs Inter (1 Nov 00:45 PKT, Serie A)
- FAISLA: **LEAN 0.5%** - Inter win @ 2.0 | chance 47% (conservative) / 51% (median) | min odds 2.38 | tier LEAN
- 5-pattern: saath
- Closest market: Inter win @ 2.0 | chance 47%/51% | min odds 2.38 | cells 3 pass/3 fail
- Trigger odds: STRONG ke liye odds >= 2.50 (lekin chance 47% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (11%), 1-2 (9%)
- Analysis (37 words): Milan home L20 10-5-5 (GF 1.5, GA 1.15); Inter away 14-4-2 (GF 2.05, GA 0.9). Goal estimate 2.80, H2H 6 games avg 2.67 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: LEAN Inter win @2.0, chance 47-51%, 5-pattern SAATH.

### Como vs Venezia (1 Nov 16:30 PKT, Serie A)
- FAISLA: **NO BET**
- 5-pattern: neutral
- Closest market: Draw @ 6.0 | chance 16%/17% | min odds 7.93 | cells 2 pass/6 fail
- Trigger odds: STRONG ke liye odds >= 8.33 (lekin chance 16% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 2-0 (10%), 2-1 (9%)
- Analysis (38 words): Como home L20 11-6-3 (GF 1.8, GA 0.75); Venezia away 0-8-12 (GF 0.85, GA 1.8). Goal estimate 2.60, H2H 2 games avg 3.00 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Draw @6.0, chance 16-17%, 5-pattern NEUTRAL.

### Frosinone vs Torino (1 Nov 19:00 PKT, Serie A)
- FAISLA: **LEAN 0.5%** - Frosinone win @ 2.15 | chance 47% (conservative) / 48% (median) | min odds 2.35 | tier LEAN-A
- 5-pattern: saath
- Closest market: Frosinone win @ 2.15 | chance 47%/48% | min odds 2.35 | cells 1 pass/3 fail
- Trigger odds: LEAN ke liye odds >= 2.28 | STRONG ke liye odds >= 2.47 (lekin chance 47% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (10%), 2-1 (9%)
- Analysis (37 words): Frosinone home L20 9-3-8 (GF 1.7, GA 1.55); Torino away 4-6-10 (GF 1.0, GA 1.65). Goal estimate 2.95, H2H 2 games avg 0.00 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: LEAN-A Frosinone win @2.15, chance 47-48%, 5-pattern SAATH.

### Lazio vs Cagliari (1 Nov 19:00 PKT, Serie A)
- FAISLA: **LEAN 0.5%** - BTTS Yes @ 2.0 | chance 42% (conservative) / 53% (median) | min odds 3.00 | tier LEAN [VALUE BET, kam hit-rate]
- 5-pattern: neutral
- Closest market: Over 2.5 @ 1.82 | chance 48%/52% | min odds 2.21 | cells 1 pass/4 fail
- Trigger odds: LEAN ke liye odds >= 2.00 | STRONG ke liye odds >= 2.32 (lekin chance 48% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 2-0 (12%), 1-0 (12%)
- Analysis (37 words): Lazio home L20 10-6-4 (GF 1.4, GA 1.25); Cagliari away 6-5-9 (GF 1.05, GA 1.6). Goal estimate 2.65, H2H 6 games avg 2.17 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: LEAN BTTS Yes @2.0, chance 42-53%, 5-pattern NEUTRAL.

### Lecce vs Genoa (1 Nov 22:00 PKT, Serie A)
- FAISLA: **NO BET**
- 5-pattern: ulta
- Closest market: Over 2.25 @ 2.08 | chance 50%/56% | min odds 2.36 | cells 4 pass/2 fail
- Trigger odds: STRONG ke liye odds >= 2.48 (lekin chance 50% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-1 (13%), 0-1 (13%)
- Analysis (39 words): Lecce home L20 6-4-10 (GF 0.7, GA 1.4); Genoa away 4-6-10 (GF 0.9, GA 1.35). Goal estimate 2.17, H2H 6 games avg 1.33 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Over 2.25 @2.08, chance 50-56%, 5-pattern ULTA.

### Juventus vs Napoli (2 Nov 00:45 PKT, Serie A)
- FAISLA: **LEAN 0.5%** - Juventus win @ 2.3 | chance 40% (conservative) / 46% (median) | min odds 2.86 | tier LEAN [VALUE BET, kam hit-rate]
- 5-pattern: neutral
- Closest market: Juventus win @ 2.3 | chance 40%/46% | min odds 2.86 | cells 3 pass/5 fail
- Trigger odds: STRONG ke liye odds >= 3.00 (lekin chance 40% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (13%), 1-0 (11%)
- Analysis (37 words): Juventus home L20 10-8-2 (GF 1.7, GA 0.7); Napoli away 10-4-6 (GF 1.4, GA 1.0). Goal estimate 2.40, H2H 6 games avg 2.17 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: LEAN Juventus win @2.3, chance 40-46%, 5-pattern NEUTRAL.

### Troyes vs Le Mans (1 Nov 00:45 PKT, Ligue 1)
- FAISLA: **NO BET** (data kam, 57-E: kisi team ke <10 match)
- 5-pattern: ulta
- Closest market: Troyes win @ 2.35 | chance 44%/47% | min odds 2.61 | cells 3 pass/3 fail
- Trigger odds: STRONG ke liye odds >= 2.74 (lekin chance 44% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-1 (12%), 1-0 (9%)
- Analysis (30 words): Troyes home L20 0-1-3 (GF 0.75, GA 2.75); Le Mans away 0-2-2 (GF 1.25, GA 2.0). Goal estimate 3.38, no H2H. Not goal-bullish. Gate: NO BET, too little data (57-E).

### Strasbourg vs Auxerre (1 Nov 19:00 PKT, Ligue 1)
- FAISLA: **NO BET**
- 5-pattern: saath
- Closest market: Strasbourg win @ 1.8 | chance 54%/54% | min odds 1.88 | cells 0 pass/1 fail
- Trigger odds: LEAN ke liye odds >= 1.88 | STRONG ke liye odds >= 1.97
- 2 likely scores: 1-1 (11%), 2-1 (10%)
- Analysis (39 words): Strasbourg home L20 10-4-6 (GF 1.7, GA 1.2); Auxerre away 3-6-11 (GF 1.1, GA 1.85). Goal estimate 2.92, H2H 4 games avg 2.00 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Strasbourg win @1.8, chance 54-54%, 5-pattern SAATH.

### Lyon vs Angers (1 Nov 21:15 PKT, Ligue 1)
- FAISLA: **NO BET**
- 5-pattern: neutral
- Closest market: Draw @ 5.0 | chance 16%/17% | min odds 7.93 | cells 2 pass/6 fail
- Trigger odds: STRONG ke liye odds >= 8.33 (lekin chance 16% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 2-0 (11%), 2-1 (10%)
- Analysis (38 words): Lyon home L20 14-2-4 (GF 1.85, GA 1.05); Angers away 4-5-11 (GF 0.75, GA 1.7). Goal estimate 2.67, H2H 4 games avg 1.50 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Draw @5.0, chance 16-17%, 5-pattern NEUTRAL.

### Paris FC vs Monaco (1 Nov 21:15 PKT, Ligue 1)
- FAISLA: **LEAN 0.5%** - Paris FC win @ 2.3 | chance 40% (conservative) / 47% (median) | min odds 2.86 | tier LEAN [VALUE BET, kam hit-rate]
- 5-pattern: neutral
- Closest market: Under 2.75 @ 1.8 | chance 52%/57% | min odds 2.01 | cells 1 pass/5 fail
- Trigger odds: LEAN ke liye odds >= 1.89 | STRONG ke liye odds >= 2.11 | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-1 (12%), 1-0 (9%)
- Analysis (37 words): Paris FC home L20 9-5-6 (GF 1.7, GA 1.45); Monaco away 8-5-7 (GF 1.55, GA 1.65). Goal estimate 3.17, H2H 2 games avg 3.00 goals. Not goal-bullish. Gate: LEAN Paris FC win @2.3, chance 40-47%, 5-pattern NEUTRAL.

### Marseille vs Toulouse (2 Nov 00:45 PKT, Ligue 1)
- FAISLA: **NO BET**
- 5-pattern: saath
- Closest market: Marseille win @ 1.92 | chance 47%/48% | min odds 2.35 | cells 1 pass/3 fail
- Trigger odds: LEAN ke liye odds >= 2.28 | STRONG ke liye odds >= 2.47 (lekin chance 47% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (10%), 2-1 (10%)
- Analysis (39 words): Marseille home L20 12-4-4 (GF 2.35, GA 1.3); Toulouse away 6-6-8 (GF 1.5, GA 1.4). Goal estimate 3.27, H2H 6 games avg 3.00 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Marseille win @1.92, chance 47-48%, 5-pattern SAATH.

### Amedspor vs Eyupspor (1 Nov 15:30 PKT, Super Lig)
- FAISLA: **NO BET** (data kam, 57-E: kisi team ke <10 match)
- 5-pattern: ulta
- Closest market: Under 3 @ 1.82 | chance 46%/55% | min odds 2.44 | cells 1 pass/5 fail
- Trigger odds: LEAN ke liye odds >= 1.87 | STRONG ke liye odds >= 2.56 (lekin chance 46% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 2-0 (13%), 1-0 (11%)
- Analysis (29 words): Amedspor home L20 5-0-0 (GF 2.8, GA 0.6); Eyupspor away 3-5-12 (GF 0.65, GA 1.95). Goal estimate 3.00, no H2H. Not goal-bullish. Gate: NO BET, too little data (57-E).

### Istanbul BB vs Samsunspor (1 Nov 18:00 PKT, Super Lig)
- FAISLA: **LEAN 0.5%** - Buyuksehyr win @ 1.8 | chance 54% (conservative) / 58% (median) | min odds 1.88 | tier LEAN-A
- 5-pattern: saath
- Closest market: Buyuksehyr win to nil @ 3.5 | chance 30%/32% | min odds 3.60 | cells 3 pass/2 fail
- Trigger odds: STRONG ke liye odds >= 3.78 (lekin chance 30% < 50% => STRONG nahi banegi, sirf LEAN/VALUE) | 5-pattern ULTA hai -> odds barhne par bhi BET nahi
- 2 likely scores: 1-1 (11%), 2-1 (10%)
- Analysis (36 words): Istanbul BB home L20 11-5-4 (GF 2.15, GA 1.05); Samsunspor away 6-5-9 (GF 1.3, GA 1.7). Goal estimate 3.10, H2H 6 games avg 2.00 goals. Not goal-bullish. Gate: LEAN-A Buyuksehyr win @1.8, chance 54-58%, 5-pattern SAATH.

### Trabzonspor vs Gaziantep (1 Nov 18:00 PKT, Super Lig)
- FAISLA: **NO BET**
- 5-pattern: neutral
- Closest market: Draw @ 5.4 | chance 15%/17% | min odds 8.98 | cells 2 pass/7 fail
- Trigger odds: STRONG ke liye odds >= 9.43 (lekin chance 15% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 2-0 (10%), 2-1 (10%)
- Analysis (38 words): Trabzonspor home L20 12-6-2 (GF 2.05, GA 0.95); Gaziantep away 6-5-9 (GF 1.35, GA 1.7). Goal estimate 3.02, H2H 6 games avg 3.33 goals. Goal-bullish: BTTS No/Under/WTN blocked. Gate: NO BET; closest Draw @5.4, chance 15-17%, 5-pattern NEUTRAL.

### Kasimpasa vs Besiktas (1 Nov 21:00 PKT, Super Lig)
- FAISLA: **NO BET**
- 5-pattern: neutral
- Closest market: Over 2.75 @ 1.85 | chance 45%/52% | min odds 2.28 | cells 0 pass/5 fail
- Trigger odds: LEAN ke liye odds >= 2.28 | STRONG ke liye odds >= 2.39 (lekin chance 45% < 50% => STRONG nahi banegi, sirf LEAN/VALUE)
- 2 likely scores: 1-1 (10%), 0-1 (10%)
- Analysis (37 words): Kasimpasa home L20 6-9-5 (GF 1.1, GA 1.1); Besiktas away 9-5-6 (GF 1.65, GA 1.25). Goal estimate 2.55, H2H 6 games avg 3.00 goals. Not goal-bullish. Gate: NO BET; closest Over 2.75 @1.85, chance 45-52%, 5-pattern NEUTRAL.

