# FINAL PICK PROTOCOL (Section 63)

## 63-0 Sab se upar (precedence)
Section 63 ka rule 57-62 aur purane sab sections par bhari hai. Conflict me yahi chalta hai. Pick banane se pehle pick_gate.py chalana LAZMI hai; gate ka output hi faisla hai. Apni andaze/dimagh se tier badalna mana. Gate ko galat lage to pehle user ko batao, khud mat badlo.

## 63-1 Goal-bullish (code nikalta hai)
Goal-bullish = BTTS Yes <=1.55 YA O2.5 <=1.60 YA (Serie A pichle 14 match avg >=3.2). Is par BLOCK: BTTS No, har Under line (1.5 se 4.5), Win-to-nil. Win-to-nil block meri taraf se tarkeeb hai (WTN BTTS No ka hissa hai), 62 me likha nahi tha. 'Fav 1.5-2.1 = goal-bullish' qaida NAHI hai (history ne support nahi kiya). Block ko 'sirf closest market' ke taur par bhi pick nahi banana; sirf blocked list me dikhana.

## 63-2 5-pattern (saath / ulta / neutral)
5 cheezen: home overall, away overall, H2H (3+ match), home GHAR L20, away BAHAR L20. Goal markets: OVER ki taraf agar andaza >=2.9, ya ghar+bahar O2.5 avg >=60%, ya H2H >=3 match (O2.5 <1.60 ho to >=2) avg >=3.5. UNDER sirf andaza <2.2 (kamzor saboot). BTTS% vote nahi karta. Result markets: venue ppg gap se; win-type SAATH >=+0.5, ULTA <=-0.2; DC-type SAATH >=0, ULTA <=-0.5; venue L20 me >=10 haar = trap, ULTA; Draw/12 hamesha NEUTRAL. Har pick me ek line: 5-pattern: saath / ulta / neutral. ULTA = BET nahi, sirf closest + trigger.

## 63-3 Tier table
STRONG (stake 2%): sab stable cells margin x1.05 se pass, >=3 cells, chance_min >=50%, 5-pattern SAATH. LEAN (0.5%): All cell + >=1 aur cell pass, evmed >0, Draw/Dog win nahi, 5-pattern ULTA nahi; chance_min <45% ho to 'VALUE BET, kam hit-rate'. LEAN-A (0.5%): sirf Fav win / Over 2.5, evmed >0, evmin >-5%. NO BET: baqi sab. Purana LEAN 1% (23.4) khatam; ab 0.5%. 'Strong' lafz sirf gate ke STRONG par.

## 63-4 NO BET me bhi closest market + trigger odds
NO BET sirf ek lafz nahi (39 purana). Hamesha likho: CLOSEST MARKET (odds, chance, min odds, edge, 5-pattern) aur TRIGGER ODDS (LEAN/STRONG ke liye kitne odds par). Gate ye line khud deta hai; copy karo. 5-pattern ULTA closest ho to 'odds barhne par bhi BET nahi' likho.

## 63-5 Live gates
Gate me --live "60 0-0" se: fav <=1.50 + 0-0 -> Under (goals+1.5) nahi (58-A); 57-A, 58-B, 58-C bhi code me. Live me bhi goal-bullish block lagta hai.

## 63-6 Jawab ka format (har pick)
(1) FAISLA + tier + stake + confidence %. (2) 5-pattern: saath / ulta. (3) Closest market + trigger odds. (4) 50-word English analysis. (5) Top 2 likely scores. (6) Roman Urdu me baqi. (7) Aakhir me: OK 3x recheck: data . rules . maths. Odds >=1.80 hi. Ek decisive bet, 'ya yeh ya wo' nahi. Team news (51) dekh kar hi final. Number code se; guess se nahi.

## 63-7 Kabhi nahi (purani galtiyan)
(a) BTTS Yes ko galat TRAP kehna: PRICE- != TRAP (62-C); TRAP sirf Odds_Signal_Table se. (b) 5-pattern ULTA par LEAN/BET dena. (c) 'Strong' lafz <50% chance wali bet par. (d) Goal-bullish match me BTTS No/Under/WTN dena (Fiorentina BTTS No 2.65, Under 3.5 jaisi galtiyan). (e) Draw ya Dog win ko LEAN banana (sirf N2, 0.5%, kam bharosa). (f) 'pakki/guarantee'. (g) Cover combo (skip).

## 63-8 Backtest saboot aur sacchai
62-A ka O2.5 hissa data se supported; BTTS Yes <=1.55 wala hissa test nahi ho sakta (BTTS odds history nahi); isliye Pick_Tracker me BTTS odds likho aur 20 match baad test karo. 62-E regime ka pichli history me persistence nahi mila; hard block sirf is liye hai ke last-14 >=3.2 hai, har baar code dobara naapta hai. BTTS No @2.4+ average me +EV hai par ~58% haarta hai; block hit-rate/risk-control ka faisla hai. Fiorentina ka 5-pattern tested definition me NEUTRAL tha; asli rukawat 62-A thi. UNDER lean aur DC/win gap cutoffs ka kuch hissa design hai; 20 picks baad dobara calibrate. Gate test me post-match Team_Summary ka chota hindsight leak. Qaide galtiyan kam karte hain, jeet ki guarantee nahi.

## 63-9 Pick_Tracker convention
Schema nahi badla. Pick column: Closest: <market> @odds (trigger >=X). Lesson column 5-pattern: SAATH/ULTA/NEUTRAL | se shuru. Har NO BET match ke baad review (user ka hukm). BTTS odds bhi note karo.

## 63-10 Tools
Toolkit me pick_gate.py.txt (rename .py). Data folder se chalao: python3 pick_gate.py LEAGUE Home Away "H=..,D=..,A=..,BTTS_Y=..,BTTS_N=..,O2.5=.." [--pick KEY] [--live "60 0-0"] [--month N]. Detail: toolkit/FINAL_PICK_PROTOCOL.md.
